"""Kidneyformer model architecture for pretraining and finetuning.

Implements the multimodal time-series transformer described in the manuscript:
- visit-level multimodal examination encoder (tabular + optional CXR);
- days-since-first-visit temporal positional embedding;
- auto-regressive (causal) GPT-2 temporal transformer;
- task-specific heads for downstream prediction or masked-feature pretraining;
- adversarial de-biasing via a Gradient Reversal Layer feeding a cohort
  discriminator and a missingness discriminator (DANN-style).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
from einops import rearrange
from transformers import BertConfig
from transformers import GPT2Model, BertModel


# ---------------------------------------------------------------------------
# Gradient reversal layer (DANN, Ganin & Lempitsky 2015)
# ---------------------------------------------------------------------------

class _GradReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambda_):
        ctx.lambda_ = float(lambda_)
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.lambda_, None


def grad_reverse(x, lambda_):
    """Identity in the forward pass; negate-and-scale gradient in backward."""
    return _GradReverse.apply(x, lambda_)


# ---------------------------------------------------------------------------
# Discriminator heads for adversarial de-biasing
# ---------------------------------------------------------------------------

class CohortDiscriminator(nn.Module):
    """Patient-level classifier over cohort labels.

    Operates on the pooled temporal representation; trained adversarially via
    the GRL to suppress cohort-specific features in the encoder output.
    """

    def __init__(self, hidden_dim, n_cohorts, dropout=0.1):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, n_cohorts),
        )

    def forward(self, x):
        return self.classifier(x)


class MissingnessDiscriminator(nn.Module):
    """Per-visit, per-feature missingness classifier.

    Outputs a single logit per (visit, feature) pair predicting whether the
    raw feature value was missing. Adversarial training forces the visit
    encoder to learn missingness-invariant representations.
    """

    def __init__(self, hidden_dim, n_features, dropout=0.1):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, n_features),
        )

    def forward(self, x):
        return self.classifier(x)


# ---------------------------------------------------------------------------
# CXR image encoder
# ---------------------------------------------------------------------------

class CXRFeatureExtractor(nn.Module):
    """Pre-trained ViT-Large DINOv2 backbone projected to the transformer dim.

    With ``freeze_backbone=True`` the ViT-L weights are non-trainable and the
    forward call runs the backbone under ``torch.no_grad()``. This is the
    "linear probe" configuration described in the manuscript: DINOv2 acts as
    a fixed feature extractor and only ``self.projection`` learns. It cuts
    per-step time ~3–4× (no ViT-L backward) and saves ~3 GB / GPU of
    optimizer state.
    """

    def __init__(self, output_dim=768, pretrained=True, freeze_backbone=False,
                 img_size=518, grad_checkpoint=False, compile_backbone=False,
                 compile_mode='default', compile_dynamic=True):
        super().__init__()
        # `img_size` must match what the dataset feeds in: timm's PatchEmbed
        # asserts on the input H/W and won't auto-resize. DINOv2 was
        # pretrained at 518; passing any other value here makes timm
        # interpolate the positional embedding to match the new patch grid.
        self.backbone = timm.create_model(
            'vit_large_patch14_dinov2.lvd142m',
            pretrained=pretrained,
            num_classes=0,
            img_size=img_size,
        )
        backbone_dim = self.backbone.num_features
        self.projection = nn.Linear(backbone_dim, output_dim)
        self.freeze_backbone = freeze_backbone
        if freeze_backbone:
            for p in self.backbone.parameters():
                p.requires_grad_(False)
            self.backbone.eval()
        elif grad_checkpoint:
            # ~50% activation-memory reduction for ~10-20% per-step recompute
            # cost. Only meaningful when the backbone is trainable.
            if hasattr(self.backbone, 'set_grad_checkpointing'):
                self.backbone.set_grad_checkpointing(enable=True)
            else:
                raise RuntimeError(
                    "timm backbone does not expose set_grad_checkpointing; "
                    "upgrade timm or set cxr_grad_checkpoint=false."
                )

        # torch.compile pass on the ViT — typical 1.1-1.8x speedup at bf16.
        # `dynamic=True` is the default: subset-forward feeds DINOv2 with a
        # varying batch dim (only the CXR-bearing samples per batch), so a
        # shape-specialized (dynamic=False) graph would hit dynamo's recompile
        # limit (8) and silently fall back to eager. The shape-polymorphic
        # graph trades some kernel specialization for "compile once, run on
        # any batch size".
        if compile_backbone:
            self.backbone = torch.compile(
                self.backbone, mode=compile_mode, dynamic=compile_dynamic,
            )

    def train(self, mode: bool = True):
        super().train(mode)
        # Keep the backbone in eval mode (no dropout) even when the parent
        # module is set to train — required for stable linear-probe training.
        if self.freeze_backbone:
            self.backbone.eval()
        return self

    def forward(self, x):
        # x: (B, 3, H, W) — H = W = config['img_size'] (default 518)
        if self.freeze_backbone:
            with torch.no_grad():
                feats = self.backbone(x)
        else:
            feats = self.backbone(x)
        return self.projection(feats)


# ---------------------------------------------------------------------------
# VAE-style multimodal fusion utilities
# ---------------------------------------------------------------------------

class VAEEncoder(nn.Module):
    """Outputs mean and log-variance for a diagonal-Gaussian latent."""

    def __init__(self, input_dim, latent_dim):
        super().__init__()
        self.mean_projection = nn.Linear(input_dim, latent_dim)
        self.logvar_projection = nn.Linear(input_dim, latent_dim)

    def forward(self, x):
        return self.mean_projection(x), self.logvar_projection(x)


def reparameterize(mean, logvar):
    std = torch.exp(0.5 * logvar)
    return mean + torch.randn_like(std) * std


def kl_divergence(mean, logvar):
    return -0.5 * torch.sum(1 + logvar - mean.pow(2) - logvar.exp(), dim=-1)


def symmetric_kl_divergence(mean1, logvar1, mean2, logvar2):
    var1 = torch.exp(logvar1)
    var2 = torch.exp(logvar2)
    kl_12 = 0.5 * torch.sum(
        logvar2 - logvar1 + (var1 + (mean1 - mean2).pow(2)) / var2 - 1, dim=-1,
    )
    kl_21 = 0.5 * torch.sum(
        logvar1 - logvar2 + (var2 + (mean2 - mean1).pow(2)) / var1 - 1, dim=-1,
    )
    return kl_12 + kl_21


# ---------------------------------------------------------------------------
# Temporal positional embedding
# ---------------------------------------------------------------------------

class TemporalPositionalEmbedding(nn.Module):
    """Visit-time embedding plus irregular follow-up gap encoding.

    Default: absolute ``t_k`` = days since first visit, clamped to
    ``[0, max_time_days]``.

    With ``signed_time=True`` (treatment-relative axis): ``t_k`` may be
    negative (pre-intervention) or positive (post-intervention). Indices are
    shifted by ``max_time_days`` into an embedding table of size
    ``2 * max_time_days + 1``. Padding should use ``0`` (intervention day) or
    any in-range value; attention ``valid_mask`` drops padded steps.
    """

    def __init__(self, max_time_days=3650, embedding_dim=768, use_time_gap=True,
                 signed_time=False):
        super().__init__()
        self.max_time_days = int(max_time_days)
        self.signed_time = bool(signed_time)
        n_pos = (2 * self.max_time_days + 1) if self.signed_time else (self.max_time_days + 1)
        self.temporal_embedding = nn.Embedding(n_pos, embedding_dim)
        self.use_time_gap = bool(use_time_gap)
        if self.use_time_gap:
            self.time_gap_proj = nn.Linear(1, embedding_dim)

    def forward(self, time_days):
        if self.signed_time:
            t = torch.clamp(time_days, -self.max_time_days, self.max_time_days)
            idx = t + self.max_time_days
        else:
            idx = torch.clamp(time_days, 0, self.max_time_days)
        abs_emb = self.temporal_embedding(idx)
        if not self.use_time_gap:
            return abs_emb
        # Gap uses signed delta magnitude so pre/post irregular intervals both count.
        dt = torch.zeros_like(time_days, dtype=abs_emb.dtype)
        dt[:, 1:] = (time_days[:, 1:] - time_days[:, :-1]).to(abs_emb.dtype).abs()
        log_dt = torch.log1p(dt).unsqueeze(-1)
        return abs_emb + self.time_gap_proj(log_dt)


# ---------------------------------------------------------------------------
# Multimodal examination encoder
# ---------------------------------------------------------------------------

class MultimodalExaminationEncoder(nn.Module):
    """Per-visit BERT encoder fusing discretized tabular features with CXR.

    A per-sample `cxr_present` mask gates the image contribution so patients
    without an image receive no spurious image bias.
    """

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.use_vae = config.get('use_vae', False)
        self.latent_dim = config.get('latent_dim', 256)

        tr_cfg = config['transformer']
        hidden_size = tr_cfg.hidden_size if hasattr(tr_cfg, 'hidden_size') else tr_cfg['hidden_size']
        n_heads = int(config.get('visit_encoder_heads')
                      or (tr_cfg.n_head if hasattr(tr_cfg, 'n_head') else tr_cfg.get('num_attention_heads', 8)))
        drop_p = float(config.get('hidden_dropout_prob',
                                  tr_cfg.resid_pdrop if hasattr(tr_cfg, 'resid_pdrop') else 0.1))
        ff_size = int(config.get('visit_encoder_ff')
                      or (tr_cfg.n_inner if hasattr(tr_cfg, 'n_inner') else hidden_size * 4))

        # NOTE: the BertModel below carries its own word and token-type
        # embeddings (initialized from vocab_size / type_vocab_size). The
        # earlier code also defined a standalone self.token_embedding /
        # self.type_embedding pair — they were never referenced in forward
        # and showed up as "unused parameters" in DDP, forcing the
        # find_unused_parameters trace at every step. Removed.

        self.use_img_model = config.get('use_img_model', False)
        if self.use_img_model:
            self.cxr_extractor = CXRFeatureExtractor(
                output_dim=hidden_size,
                pretrained=config.get('img_pretrained', True),
                freeze_backbone=config.get('freeze_cxr_backbone', False),
                img_size=config.get('img_size', 518),
                grad_checkpoint=config.get('cxr_grad_checkpoint', False),
                compile_backbone=config.get('compile_cxr_backbone', False),
                compile_mode=config.get('cxr_compile_mode', 'default'),
                compile_dynamic=config.get('cxr_compile_dynamic', True),
            )
            self.cxr_projection = nn.Linear(hidden_size, hidden_size)
            # Learned token used when a visit has no chest radiograph.
            self.missing_cxr_token = nn.Parameter(torch.zeros(hidden_size))

        # Discrete bins are 0..255; missing / padding uses id 256.
        self.missing_token_id = int(config.get('missing_token_id', 256))
        self.use_gated_fusion = bool(config.get('use_gated_fusion', True))

        # `add_pooling_layer=False` and `max_position_embeddings=1` together
        # strip out two boilerplate modules BertModel would otherwise create:
        # the pooler (we don't call it; we read [CLS] directly) and the 8192-
        # position absolute embedding table (position_embedding_type='none'
        # already disables its use, but the parameter still gets allocated).
        # Removing them eliminates ~3M parameters that would otherwise be
        # flagged as "unused" by DDP's gradient sync and force the expensive
        # find_unused_parameters trace on every step.
        self.visit_encoder = BertModel(BertConfig(
            vocab_size=self.missing_token_id + 1,
            hidden_size=hidden_size,
            num_hidden_layers=config.get('visit_encoder_layers', 6),
            num_attention_heads=n_heads,
            intermediate_size=ff_size,
            hidden_act="gelu",
            hidden_dropout_prob=drop_p,
            attention_probs_dropout_prob=drop_p,
            max_position_embeddings=1,
            type_vocab_size=config['n_category_feats'] + config['n_float_feats'] + 1,
            initializer_range=0.02,
            layer_norm_eps=1e-12,
            pad_token_id=self.missing_token_id,
            position_embedding_type="none",
            use_cache=True,
            classifier_dropout=None,
        ), add_pooling_layer=False)

        if self.use_vae:
            self.labtest_vae_encoder = VAEEncoder(hidden_size, self.latent_dim)
            if self.use_img_model:
                self.cxr_vae_encoder = VAEEncoder(hidden_size, self.latent_dim)
            self.latent_decoder = nn.Linear(self.latent_dim, hidden_size)
            if self.use_gated_fusion and self.use_img_model:
                # Residual gate: fused = z_lab + present * gate(z_lab,z_img) * z_img
                self.fusion_gate = nn.Sequential(
                    nn.Linear(self.latent_dim * 2, self.latent_dim),
                    nn.Sigmoid(),
                )

        self.register_buffer(
            "token_type_ids",
            torch.arange(config['n_category_feats'] + config['n_float_feats'] + 1),
            persistent=False,
        )
        self.register_buffer("one", torch.ones(1, dtype=torch.long), persistent=False)
        self.register_buffer("zero", torch.zeros(1, dtype=torch.long), persistent=False)

    def _scatter_cxr(self, tabular_features, cxr_images, cxr_present, cxr_slots):
        """Per-visit DINOv2 features. Missing visits stay zero here; the caller adds the empty token."""
        B, L, _ = tabular_features.shape
        hidden = tabular_features.shape[-1]
        out = tabular_features.new_zeros(B, L, hidden)
        present = cxr_present
        if cxr_images is None or cxr_slots is None or cxr_images.shape[0] == 0:
            return out, present
        enc = self.cxr_extractor(cxr_images)
        b_idx = cxr_slots[:, 0].long()
        t_idx = cxr_slots[:, 1].long()
        keep = present[b_idx, t_idx]
        if keep.any():
            out[b_idx[keep], t_idx[keep]] = enc[keep].to(out.dtype)
        return out, present

    def _apply_cxr(self, tabular_features, cxr_images, cxr_present, cxr_slots=None):
        """CXR contribution gated by the per-sample `cxr_present` mask.

        Only the subset of samples with cxr_present=True are pushed through
        DINOv2 (which is the bulk of the per-step cost); the rest stay as
        zeros. This is ~6× faster than the all-batch forward when CXR
        prevalence is ~15% as in COMPASS.

        When ``cxr_present`` is (B, L) the image is bound to that visit.
        Visits without a film are left at zero so the caller can insert the
        empty-image token. A (B,) mask keeps the previous behaviour of
        broadcasting one film across the sequence.

        Returns ``None`` when no sample in the batch has an image, letting
        the caller skip the projection step entirely.
        """
        if not (self.use_img_model and hasattr(self, 'cxr_extractor')):
            return None
        if cxr_images is None:
            return None
        if cxr_present is not None and cxr_present.dim() == 2:
            scattered, _ = self._scatter_cxr(
                tabular_features, cxr_images, cxr_present, cxr_slots,
            )
            return scattered
        if cxr_present is not None and not cxr_present.any():
            return None

        B, L, D = tabular_features.shape
        if cxr_present is not None:
            idx = cxr_present.nonzero(as_tuple=True)[0]
            present_feats = self.cxr_extractor(cxr_images[idx])  # (k, D)
            full = torch.zeros(
                B, present_feats.shape[-1],
                device=present_feats.device, dtype=present_feats.dtype,
            )
            full[idx] = present_feats
        else:
            full = self.cxr_extractor(cxr_images)  # (B, D)

        cxr_features = full.unsqueeze(1).expand(-1, L, -1)  # (B, L, D)
        return cxr_features

    def forward(self, cat_feats, float_feats, cxr_images=None,
                cxr_present=None, ehr_present=None, cxr_slots=None):
        B = cat_feats.shape[0]
        L = cat_feats.shape[2]
        hidden_size = self.config['transformer'].hidden_size

        # Fast path for image-only inference: when ehr_present is False for
        # every sample in the batch, the tabular encoder's output gets gated
        # to zero downstream anyway, so we skip the (expensive) BertModel
        # forward and just emit a zero placeholder. This is the dominant
        # cost of the img_only ablation pass at ~3-4x faster vs running BERT
        # and throwing the result away.
        if ehr_present is not None and not ehr_present.any():
            ref_dtype = next(self.visit_encoder.parameters()).dtype
            tabular_features = torch.zeros(
                B, L, hidden_size,
                device=cat_feats.device, dtype=ref_dtype,
            )
            vae_losses = {}
            cxr_features = self._apply_cxr(tabular_features, cxr_images, cxr_present)
            if cxr_features is not None:
                cxr_proj = self.cxr_projection(cxr_features)
                if cxr_present is not None:
                    gate = cxr_present.to(cxr_proj.dtype).view(B, 1, 1)
                    cxr_proj = cxr_proj * gate
                visit_embeddings = cxr_proj
            else:
                visit_embeddings = tabular_features
            return visit_embeddings, vae_losses

        cat_feats_mask = (cat_feats < 0) | (cat_feats == self.missing_token_id)
        float_feats_mask = (float_feats < 0) | (float_feats == self.missing_token_id)
        attention_mask = torch.cat([
            self.one.unsqueeze(1).unsqueeze(0).expand(B, -1, L),
            ~cat_feats_mask,
            ~float_feats_mask,
        ], dim=1)
        attention_mask = rearrange(attention_mask, 'b n l -> (b l) n')

        # Values stay in 0..255; missing / pad id is 256 (padding_idx).
        cat_ids = cat_feats.clone()
        cat_ids[cat_feats_mask] = self.missing_token_id
        float_ids = float_feats.clone()
        float_ids[float_feats_mask] = self.missing_token_id
        input_ids = torch.cat([
            self.zero.unsqueeze(1).unsqueeze(0).expand(B, -1, L),
            cat_ids,
            float_ids,
        ], dim=1)
        input_ids = rearrange(input_ids, 'b n l -> (b l) n')

        BL = input_ids.shape[0]
        token_type_ids = self.token_type_ids.unsqueeze(0).expand(BL, -1)

        tabular_output = self.visit_encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        ).last_hidden_state

        tabular_features = tabular_output[:, 0, :]
        tabular_features = rearrange(tabular_features, '(b l) d -> b l d', b=B)

        # Gate EHR contribution by per-sample `ehr_present` mask. With
        # modality-dropout training and inference-time mode flags, this is
        # how the model is told "treat this sample's EHR as missing" —
        # critical for imaging-only inference. Default (None) = always on.
        if ehr_present is not None:
            ehr_gate = ehr_present.to(tabular_features.dtype).view(B, 1, 1)
            tabular_features = tabular_features * ehr_gate

        vae_losses = {}
        per_visit = cxr_present is not None and cxr_present.dim() == 2
        cxr_features = self._apply_cxr(
            tabular_features, cxr_images, cxr_present, cxr_slots=cxr_slots,
        )

        if not self.use_vae:
            if cxr_features is not None:
                cxr_proj = self.cxr_projection(cxr_features)
                if per_visit:
                    gate = cxr_present.to(cxr_proj.dtype).unsqueeze(-1)
                    cxr_proj = cxr_proj * gate
                    missing = self.missing_cxr_token.view(1, 1, -1) * (1.0 - gate)
                    visit_embeddings = tabular_features + cxr_proj + missing
                else:
                    if cxr_present is not None:
                        gate = cxr_present.to(cxr_proj.dtype).view(B, 1, 1)
                        cxr_proj = cxr_proj * gate
                    vae_losses['cxr_contribution_norm'] = (
                        cxr_proj.detach().float().norm(dim=-1).mean()
                    )
                    visit_embeddings = tabular_features + cxr_proj
            else:
                visit_embeddings = tabular_features
            return visit_embeddings, vae_losses

        # VAE branch with residual gated fusion (Forward-0922):
        # fused_z = z_lab + present * gate([z_lab,z_img]) * z_img
        # then visit = decoder(fused_z) + H_EHR.
        labtest_mean, labtest_logvar = self.labtest_vae_encoder(tabular_features)
        labtest_z = reparameterize(labtest_mean, labtest_logvar)
        vae_losses['labtest_kl'] = kl_divergence(labtest_mean, labtest_logvar).mean()

        if cxr_features is not None:
            cxr_mean, cxr_logvar = self.cxr_vae_encoder(cxr_features)
            cxr_z = reparameterize(cxr_mean, cxr_logvar)
            cxr_kl = kl_divergence(cxr_mean, cxr_logvar)
            sym = symmetric_kl_divergence(
                labtest_mean, labtest_logvar, cxr_mean, cxr_logvar,
            )
            if per_visit:
                present = cxr_present.to(labtest_z.dtype)
                # Train-time modality dropout inside the fusion (p≈0.4).
                if self.training:
                    keep = (torch.rand_like(present) > 0.4).to(present.dtype)
                    present = present * keep
                denom = cxr_present.to(cxr_kl.dtype).sum().clamp(min=1)
                vae_losses['cxr_kl'] = (cxr_kl * cxr_present.to(cxr_kl.dtype)).sum() / denom
                vae_losses['symmetric_kl'] = (sym * cxr_present.to(sym.dtype)).sum() / denom
                if self.use_gated_fusion and hasattr(self, 'fusion_gate'):
                    gate_w = self.fusion_gate(torch.cat([labtest_z, cxr_z], dim=-1))
                    fused_z = labtest_z + present.unsqueeze(-1) * gate_w * cxr_z
                else:
                    fused_z = torch.where(
                        present.unsqueeze(-1).bool(),
                        (labtest_z + cxr_z) * 0.5,
                        labtest_z,
                    )
            else:
                vae_losses['cxr_kl'] = cxr_kl.mean()
                vae_losses['symmetric_kl'] = sym.mean()
                if cxr_present is not None:
                    present = cxr_present.to(labtest_z.dtype).view(B, 1, 1)
                    if self.training:
                        keep = (torch.rand(B, device=present.device) > 0.4).to(present.dtype).view(B, 1, 1)
                        present = present * keep
                    if self.use_gated_fusion and hasattr(self, 'fusion_gate'):
                        gate_w = self.fusion_gate(torch.cat([labtest_z, cxr_z], dim=-1))
                        fused_z = labtest_z + present * gate_w * cxr_z
                    else:
                        fused_z = labtest_z + (cxr_z - labtest_z) * 0.5 * present
                else:
                    if self.use_gated_fusion and hasattr(self, 'fusion_gate'):
                        gate_w = self.fusion_gate(torch.cat([labtest_z, cxr_z], dim=-1))
                        fused_z = labtest_z + gate_w * cxr_z
                    else:
                        fused_z = (labtest_z + cxr_z) / 2
        else:
            fused_z = labtest_z
            vae_losses['cxr_kl'] = torch.tensor(0.0, device=labtest_z.device)
            vae_losses['symmetric_kl'] = torch.tensor(0.0, device=labtest_z.device)

        visit_embeddings = self.latent_decoder(fused_z) + tabular_features
        if per_visit:
            absent = (~cxr_present).to(visit_embeddings.dtype).unsqueeze(-1)
            visit_embeddings = visit_embeddings + self.missing_cxr_token.view(1, 1, -1) * absent
        return visit_embeddings, vae_losses


# ---------------------------------------------------------------------------
# Task heads
# ---------------------------------------------------------------------------

def _masked_mean(x, mask):
    """Mask-weighted mean over the visit axis. x is [B, L, D]."""
    if mask is None:
        return x.mean(dim=1)
    m = mask.to(dtype=x.dtype).unsqueeze(-1)
    return (x * m).sum(dim=1) / m.sum(dim=1).clamp(min=1.0)


class _TxSensHead(nn.Module):
    """Binary sensitivity head that also returns its hidden state.

    The hidden state is pooled over visits and added to the regression
    features, so the sensitivity representation drives the trajectory heads.
    """

    def __init__(self, d_in: int, hidden: int, drop: float, linear: bool):
        super().__init__()
        if linear:
            self.trunk = nn.Identity()
            self.out = nn.Linear(d_in, 2)
        else:
            self.trunk = nn.Sequential(
                nn.Linear(d_in, hidden),
                nn.GELU(),
                nn.Dropout(drop),
            )
            self.out = nn.Linear(hidden, 2)

    def forward(self, x):
        h = self.trunk(x)
        return self.out(h), h


class FinetuneTaskHeads(nn.Module):
    """Per-task prediction heads for downstream clinical objectives.

    Classification heads keep the original shared-MLP (or linear) design.
    When ``task_head_arch`` is ``decoupled_reg`` / ``decoupled``, regression
    uses a shared projection followed by per-target towers so sparse targets
    do not share the final layers with well-covered ones:

      shared_proj: Linear(d_in, hidden) → GELU → Dropout
      per target:  Linear(hidden, mid) → GELU → Dropout → Linear(mid, 1)
    """

    def __init__(self, config):
        super().__init__()
        self.n_cls = list(config['n_cls'])
        tr = config['transformer']
        hidden_dim = tr.hidden_size if hasattr(tr, 'hidden_size') else tr['hidden_size']
        arch = str(config.get('task_head_arch', 'mlp')).lower()
        mlp_dim = int(config.get('task_head_hidden', 256))
        drop_p = float(config.get('task_head_dropout', 0.2))

        n_cls_tasks = len(config.get('cls_label_names') or [])
        n_reg_tasks = len(config.get('reg_label_names') or [])
        if n_cls_tasks + n_reg_tasks == 0:
            # Fallback when names are not yet filled: treat out_dim==1 as reg.
            n_cls_tasks = sum(1 for n in self.n_cls if int(n) != 1)
            n_reg_tasks = len(self.n_cls) - n_cls_tasks
        elif n_cls_tasks + n_reg_tasks != len(self.n_cls):
            # Prefer name counts; pad/truncate against n_cls length.
            n_cls_tasks = min(n_cls_tasks, len(self.n_cls))
            n_reg_tasks = len(self.n_cls) - n_cls_tasks

        cls_outs = self.n_cls[:n_cls_tasks]
        reg_outs = self.n_cls[n_cls_tasks:]

        def _make_mlp_head(n_out: int):
            if arch == 'linear':
                return nn.Linear(hidden_dim, n_out)
            return nn.Sequential(
                nn.Linear(hidden_dim, mlp_dim),
                nn.GELU(),
                nn.Dropout(drop_p),
                nn.Linear(mlp_dim, n_out),
            )

        self.cls_heads = nn.ModuleList([_make_mlp_head(int(n)) for n in cls_outs])

        use_decoupled = arch in {'decoupled_reg', 'decoupled', 'decoupled_mlp'}
        self.use_decoupled_reg = bool(use_decoupled and len(reg_outs) > 0)
        if self.use_decoupled_reg:
            mid = int(config.get('reg_head_mid', 128))
            # Independent reg towers: default dropout 0 (no stochasticity on rare targets).
            reg_drop = float(config.get('reg_head_dropout', 0.0))
            shared_drop = float(config.get('reg_shared_dropout', drop_p))
            self.shared_proj = nn.Sequential(
                nn.Linear(hidden_dim, mlp_dim),
                nn.GELU(),
                nn.Dropout(shared_drop),
            )
            self.reg_heads = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(mlp_dim, mid),
                    nn.GELU(),
                    nn.Dropout(reg_drop),
                    nn.Linear(mid, 1),
                )
                for _ in reg_outs
            ])
        else:
            self.shared_proj = None
            self.reg_heads = nn.ModuleList([_make_mlp_head(int(n)) for n in reg_outs])

        self.use_tx_proto = bool(config.get('tx_response_losses', False))
        self.cls_guide_reg = bool(config.get('cls_guide_reg', False))
        self.guide_index = None
        self.guide_proj = None
        self.last_tx = {}
        sens_name = str(config.get('tx_sens_name', 'TxSens'))
        names = list(config.get('cls_label_names') or [])
        if self.cls_guide_reg or self.use_tx_proto:
            for i, name in enumerate(names[:len(self.cls_heads)]):
                if name == sens_name or str(name).rsplit('_', 1)[-1] == sens_name:
                    self.guide_index = i
                    break
        if self.cls_guide_reg:
            if self.guide_index is None:
                raise ValueError(f'cls_guide_reg requires a {sens_name} classification head')
            linear = arch == 'linear'
            self.cls_heads[self.guide_index] = _TxSensHead(hidden_dim, mlp_dim, drop_p, linear)
            guide_dim = hidden_dim if linear else mlp_dim
            reg_dim = mlp_dim if self.shared_proj is not None else hidden_dim
            self.guide_proj = nn.Linear(guide_dim, reg_dim)
        if self.use_tx_proto:
            if self.guide_index is None:
                raise ValueError(f'tx_response_losses requires a {sens_name} classification head')
            self.proto = nn.Parameter(torch.randn(2, hidden_dim) * 0.02)
            self.traj_proto = nn.Parameter(torch.zeros(2, 3, len(self.reg_heads)))
            self.proto_tau = float(config.get('tx_proto_tau', 1.0))

        # Back-compat alias used by older code / layered-LR grouping.
        self.heads = nn.ModuleList(list(self.cls_heads) + list(self.reg_heads))

    def forward(self, x, valid_mask=None):
        outs = []
        guide = None
        for i, head in enumerate(self.cls_heads):
            if self.cls_guide_reg and i == self.guide_index:
                logits, h = head(x)
                outs.append(logits)
                guide = _masked_mean(h, valid_mask)
            else:
                outs.append(head(x))
        if self.shared_proj is not None:
            hreg = self.shared_proj(x)
        else:
            hreg = x
        if guide is not None and self.guide_proj is not None:
            hreg = hreg + self.guide_proj(guide).unsqueeze(1)
        outs.extend(head(hreg) for head in self.reg_heads)

        if self.use_tx_proto:
            z = _masked_mean(x, valid_mask)
            dist = (z.unsqueeze(1) - self.proto.unsqueeze(0)).pow(2).sum(-1)
            self.last_tx = {'proto_logits': -dist / max(self.proto_tau, 1e-4)}
        else:
            self.last_tx = {}
        return outs


class PretrainTaskHeads(nn.Module):
    """Masked-feature reconstruction heads.

    With ``predict_next_visit=True`` (manuscript default) the head additionally
    reconstructs the masked features at visit t+1, matching the MLM objective
    described in the Methods.
    """

    def __init__(self, config):
        super().__init__()
        hidden_dim = config['transformer'].hidden_size
        n_cls = len(config.get('cls_label_names', []))
        n_reg = len(config.get('reg_label_names', []))
        self.predict_next_visit = config.get('predict_next_visit', True)

        def _cls_head():
            return nn.Sequential(
                nn.Linear(hidden_dim, 256), nn.ReLU(), nn.Linear(256, 2),
            )

        def _reg_head():
            return nn.Sequential(
                nn.Linear(hidden_dim, 256), nn.ReLU(), nn.Linear(256, 1),
            )

        self.cls_heads = nn.ModuleList([_cls_head() for _ in range(n_cls)])
        self.reg_heads = nn.ModuleList([_reg_head() for _ in range(n_reg)])

        if self.predict_next_visit:
            self.next_cls_heads = nn.ModuleList([_cls_head() for _ in range(n_cls)])
            self.next_reg_heads = nn.ModuleList([_reg_head() for _ in range(n_reg)])

    def forward(self, hidden_states, cat_feats=None, float_feats=None, valid_mask=None):
        cls_predictions = [head(hidden_states) for head in self.cls_heads]
        reg_predictions = [head(hidden_states).squeeze(-1) for head in self.reg_heads]

        next_cls_predictions = []
        next_reg_predictions = []
        if self.predict_next_visit:
            next_cls_predictions = [head(hidden_states) for head in self.next_cls_heads]
            next_reg_predictions = [head(hidden_states).squeeze(-1) for head in self.next_reg_heads]

        return {
            'cls_current': cls_predictions,
            'reg_current': reg_predictions,
            'cls_next': next_cls_predictions,
            'reg_next': next_reg_predictions,
        }


# ---------------------------------------------------------------------------
# Top-level Oncoformer
# ---------------------------------------------------------------------------

class Oncoformer(nn.Module):
    """Unified Oncoformer model.

    Architecture:
      1. MultimodalExaminationEncoder — visit-level BERT fusing tabular EHR
         and (optionally, gated by `cxr_present`) CXR features.
      2. TemporalPositionalEmbedding — days-since-first-visit encoding.
      3. GPT2Model — causal temporal transformer across the visit sequence.
      4. Task heads — finetune (classification/regression) or pretrain (MLM
         reconstruction of current and, optionally, next visit).
      5. Adversarial heads (optional) — MissingnessDiscriminator on the
         per-visit encoder output and CohortDiscriminator on the pooled
         temporal representation, each fed via a Gradient Reversal Layer.

    Forward returns ``(predictions, aux)`` where ``aux`` is a dict with keys
    ``vae`` (dict of KL losses), ``cohort_logits`` (or None), and
    ``missingness_logits`` (or None).
    """

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.mode = config.get('mode', 'finetune')

        hidden_dim = config['transformer'].hidden_size

        self.multimodal_encoder = MultimodalExaminationEncoder(config)

        self.temporal_embedding = TemporalPositionalEmbedding(
            max_time_days=config.get('max_time_days', 3650),
            embedding_dim=hidden_dim,
            use_time_gap=config.get('use_time_gap', True),
            signed_time=bool(config.get('signed_time', False)),
        )

        # GPT2Model carries a (vocab_size, hidden) word-token embedding (wte).
        # We always pass `inputs_embeds=...` so wte is never used. Shrinking
        # vocab_size to 1 drops a ~12M-parameter unused tensor that would
        # otherwise force DDP into find_unused_parameters_true mode.
        tr_cfg = config['transformer']
        tr_cfg.vocab_size = 1
        self.temporal_transformer = GPT2Model(tr_cfg)

        # The visit encoder's position_embedding and the temporal transformer's
        # wte are tiny (1, hidden) tensors that are never used (their
        # respective modules are configured with position_embedding_type='none'
        # and inputs_embeds=). DDP otherwise flags them as unused and forces
        # the find_unused_parameters trace on every step. Freezing them puts
        # them in the "no gradient expected" set instead.
        self.multimodal_encoder.visit_encoder.embeddings.position_embeddings.weight.requires_grad_(False)
        self.temporal_transformer.wte.weight.requires_grad_(False)

        if self.mode == 'finetune':
            self.task_heads = FinetuneTaskHeads(config)
        else:
            self.pretrain_head = PretrainTaskHeads(config)

        # --- Adversarial de-biasing heads (optional) ---
        self.use_cohort_adv = config.get('use_cohort_adv', False)
        self.use_missingness_adv = config.get('use_missingness_adv', False)
        self.n_cohorts = int(config.get('n_cohorts', 1))
        self.n_features_total = (
            config['n_category_feats'] + config['n_float_feats']
        )

        if self.use_cohort_adv and self.n_cohorts >= 2:
            self.cohort_disc = CohortDiscriminator(
                hidden_dim=hidden_dim, n_cohorts=self.n_cohorts,
            )
        else:
            self.cohort_disc = None

        if self.use_missingness_adv:
            self.missingness_disc = MissingnessDiscriminator(
                hidden_dim=hidden_dim, n_features=self.n_features_total,
            )
        else:
            self.missingness_disc = None

        # GRL strength — updated by the Lightning module on each epoch.
        self.grl_lambda = 0.0

    def set_grl_lambda(self, value):
        self.grl_lambda = float(value)

    def forward(self, cat_feats, float_feats, valid_mask, time_index,
                cxr_images=None, cxr_present=None, ehr_present=None, cxr_slots=None, **kwargs):
        visit_embeddings, vae_losses = self.multimodal_encoder(
            cat_feats, float_feats, cxr_images, cxr_present,
            ehr_present=ehr_present, cxr_slots=cxr_slots,
        )

        # Missingness discriminator on the visit-level encoder output.
        miss_logits = None
        if self.missingness_disc is not None:
            adv_features = grad_reverse(visit_embeddings, self.grl_lambda)
            miss_logits = self.missingness_disc(adv_features)

        temporal_emb = self.temporal_embedding(time_index)
        embeddings_with_time = visit_embeddings + temporal_emb

        # Temporal information enters via `temporal_embedding`; GPT-2's own
        # positional table only knows positions 0..n_positions-1, so we let
        # it default to sequential ids rather than passing absolute days.
        temporal_output = self.temporal_transformer(
            inputs_embeds=embeddings_with_time,
            attention_mask=valid_mask,
        ).last_hidden_state

        # Cohort discriminator on a valid-mask-weighted pool of the temporal output.
        cohort_logits = None
        if self.cohort_disc is not None:
            mask_f = valid_mask.to(temporal_output.dtype).unsqueeze(-1)
            pooled = (temporal_output * mask_f).sum(dim=1) / mask_f.sum(dim=1).clamp(min=1)
            cohort_features = grad_reverse(pooled, self.grl_lambda)
            cohort_logits = self.cohort_disc(cohort_features)

        aux = {
            'vae': vae_losses,
            'cohort_logits': cohort_logits,
            'missingness_logits': miss_logits,
        }

        if self.mode == 'finetune':
            return self.task_heads(temporal_output, valid_mask=valid_mask), aux

        return self.pretrain_head(
            temporal_output, cat_feats, float_feats, valid_mask,
        ), aux
