"""Kidneyformer finetuning module for downstream clinical prediction tasks."""

import gc
import math
from pathlib import Path
from collections import defaultdict

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
import pytorch_lightning as pl
import torchmetrics.functional as MF
from torch.optim import AdamW
from torchmetrics.utilities.data import dim_zero_cat
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score
from sklearn.preprocessing import label_binarize
from tqdm import tqdm

from kidneyformer_code.kidneyformer import Oncoformer
from kidneyformer_code.kidneyformer_ddp import all_gather
from kidneyformer_code.kidneyformer_scheduler import CosineAnnealingWarmupRestarts


def group_by_M_dimension(A_list, B_list, C_list):
    """Group tensors by their second dimension for batched loss computation."""
    device = A_list[0].device
    M_values = torch.tensor([A.size(1) for A in A_list], device=device)
    unique_M = torch.unique(M_values)

    groups = {}
    for M in unique_M.cpu().numpy():
        mask = M_values == M
        indices = torch.where(mask)[0]
        groups[M] = (
            torch.cat([A_list[i] for i in indices], dim=0),
            torch.cat([B_list[i] for i in indices], dim=0),
            torch.cat([C_list[i] for i in indices], dim=0),
        )
    return groups


class AsymmetricLoss(nn.Module):
    """Asymmetric Loss (ASL) for imbalanced binary classification.

    Parameters match Ridnik et al.: focus more on hard negatives via ``gamma_neg``,
    while positives use ``gamma_pos`` (often 0). Probability margin ``clip`` (m)
    discards easy negatives with p < m.
    """

    def __init__(self, gamma_pos: float = 0.0, gamma_neg: float = 4.0,
                 clip: float = 0.05, eps: float = 1e-8, reduction: str = 'none',
                 label_smoothing: float = 0.0):
        super().__init__()
        self.gamma_pos = float(gamma_pos)
        self.gamma_neg = float(gamma_neg)
        self.clip = float(clip)
        self.eps = float(eps)
        self.reduction = reduction
        self.label_smoothing = float(label_smoothing)

    def forward(self, inputs, targets):
        # inputs: [N, 2] logits; targets: [N] in {0, 1}
        if inputs.shape[-1] != 2:
            # fall back to CE for non-binary heads
            return F.cross_entropy(inputs, targets, reduction='none')
        p = torch.softmax(inputs.float(), dim=-1)[:, 1].clamp(self.eps, 1.0 - self.eps)
        y = targets.float()
        # Soft targets: positive → 1-ε/2, negative → ε/2. Keep ε small so the
        # huge negative class does not swamp rare positives.
        eps = self.label_smoothing
        if eps > 0:
            y = y * (1.0 - eps) + 0.5 * eps

        # Positive: (1-p)^{γ+} * (-log p)
        loss_pos = (1.0 - p) ** self.gamma_pos * (-torch.log(p))

        # Negative: probability margin then (p_m)^{γ-} * (-log(1-p_m))
        p_m = p
        if self.clip is not None and self.clip > 0:
            p_m = (p - self.clip).clamp(min=0.0)
        # when p_m==0, contribution is 0 (easy negative dropped)
        one_m = (1.0 - p_m).clamp(self.eps, 1.0)
        loss_neg = (p_m ** self.gamma_neg) * (-torch.log(one_m))
        # p_m==0 → set loss_neg to 0 explicitly for stability
        loss_neg = torch.where(p_m > 0, loss_neg, torch.zeros_like(loss_neg))

        loss = y * loss_pos + (1.0 - y) * loss_neg
        if self.reduction == 'none':
            return loss
        if self.reduction == 'mean':
            return loss.mean()
        if self.reduction == 'sum':
            return loss.sum()
        raise ValueError(f"Invalid reduction mode: {self.reduction}")


class FocalLoss(nn.Module):
    """Class-balanced focal loss for imbalanced binary / multiclass heads.

    For each sample, ``alpha_t = alpha`` when target is the positive class
    (label == 1 for binary) and ``1 - alpha`` otherwise. Setting ``alpha`` > 0.5
    up-weights rare positives and typically improves AP under severe imbalance.
    """

    def __init__(self, alpha=0.75, gamma=2.0, reduction='mean'):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        # inputs: [N, C], targets: [N]
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        if inputs.shape[-1] == 2:
            alpha_t = torch.where(
                targets == 1,
                torch.full_like(ce_loss, self.alpha),
                torch.full_like(ce_loss, 1.0 - self.alpha),
            )
        else:
            alpha_t = torch.full_like(ce_loss, self.alpha)
        focal_loss = alpha_t * (1 - pt) ** self.gamma * ce_loss

        if self.reduction == 'none':
            return focal_loss
        if self.reduction == 'mean':
            return focal_loss.mean()
        if self.reduction == 'sum':
            return focal_loss.sum()
        raise ValueError(f"Invalid reduction mode: {self.reduction}")


def last_valid_visit_mask(valid_mask: torch.Tensor) -> torch.Tensor:
    """Boolean mask that keeps only the last valid visit per sequence."""
    # valid_mask: [B, L]
    B, L = valid_mask.shape
    idx = torch.arange(L, device=valid_mask.device).unsqueeze(0).expand(B, L)
    masked_idx = torch.where(valid_mask.bool(), idx, torch.full_like(idx, -1))
    last = masked_idx.max(dim=1).values.clamp(min=0)  # [B]
    out = torch.zeros_like(valid_mask, dtype=torch.bool)
    out.scatter_(1, last.unsqueeze(1), True)
    return out & valid_mask.bool()


def batch_top5_encode(probs: np.ndarray) -> np.ndarray:
    """Encode top-5 class predictions into a single integer per sample."""
    top5_indices = np.argsort(probs, axis=1)[:, -5:]
    encoded = np.zeros(len(probs), dtype=np.int64)
    for i, indices in enumerate(top5_indices):
        val = 0
        for idx in indices[::-1]:
            val = val * 41 + idx
        encoded[i] = val
    return encoded


class OncoModule(pl.LightningModule):
    """Lightning module for Oncoformer downstream finetuning.

    Forwards EHR + (gated) CXR through the model, computes per-task
    classification and regression losses, and adds the same adversarial
    de-biasing terms used at pretraining time so the encoder remains
    cohort- and missingness-invariant after task-specific adaptation.
    """

    def __init__(self, config):
        super().__init__()

        self.config = config
        self.config['mode'] = 'finetune'

        self.data_type = config.get('data_type', '')
        self.momentum = config.get('momentum', 0.9)
        self.wd = config.get('wd', 1e-6)
        self.lr = config.get('lr', 1e-3)
        self.n_nodes = config.get('n_nodes', 1)
        self.n_gpus = config.get('n_gpus', 1)
        if isinstance(self.n_gpus, list):
            self.n_gpus = len(self.n_gpus)
        self.n_epoch = config.get('n_epoch', None)

        # Datamodule.setup() already fills cls_label_names from diag_cols
        # (disease order). feat_info.category_cols is only ["sex"] and must
        # not replace those names.
        if config.get('cls_label_names'):
            self.cls_label_names = list(config['cls_label_names'])
            self.reg_label_names = list(config.get('reg_label_names') or [])
        elif 'feat_info' in config:
            self.cls_label_names = list(config['feat_info']['category_cols'])
            self.reg_label_names = list(config['feat_info']['float_cols'].keys())
        else:
            self.cls_label_names = []
            self.reg_label_names = []

        self.config['cls_label_names'] = self.cls_label_names
        self.config['reg_label_names'] = self.reg_label_names

        self.model = Oncoformer(config)

        loss_type = str(config.get('loss_type', 'focal')).lower()
        self.loss_type = loss_type
        if loss_type == 'asl':
            self.criterion = AsymmetricLoss(
                gamma_pos=float(config.get('asl_gamma_pos', 0.0)),
                gamma_neg=float(config.get('asl_gamma_neg', 4.0)),
                clip=float(config.get('asl_clip', 0.05)),
                reduction='none',
                label_smoothing=float(config.get('label_smoothing', 0.0)),
            )
        else:
            focal_alpha = float(config.get('focal_alpha', 0.75))
            focal_gamma = float(config.get('focal_gamma', 2.0))
            self.criterion = FocalLoss(alpha=focal_alpha, gamma=focal_gamma, reduction='none')
        self.loss_last_visit_only = bool(config.get('loss_last_visit_only', False))
        self.pos_loss_boost = float(config.get('pos_loss_boost', 1.0))
        self.use_class_weight = bool(config.get('use_class_weight', False))
        self.class_pos_weight = config.get('class_pos_weight') or []
        self.class_neg_weight = config.get('class_neg_weight') or []
        self.output_dir = config.get('output_dir', None)
        if self.output_dir is not None:
            self.output_dir = Path(self.output_dir) / 'pred'
            self.output_dir.mkdir(parents=True, exist_ok=True)
        self.pred_folder = 'pred'

        # Adversarial-loss configuration
        self.use_cohort_adv = config.get('use_cohort_adv', False)
        self.use_missingness_adv = config.get('use_missingness_adv', False)
        self.cohort_adv_weight = config.get('cohort_adv_weight', 0.1)
        self.missingness_adv_weight = config.get('missingness_adv_weight', 0.1)
        self.grl_lambda_max = config.get('grl_lambda_max', 1.0)

    # ------------------------------------------------------------------
    # Optimizer & scheduler
    # ------------------------------------------------------------------

    def configure_optimizers(self):
        head_lr = float(self.config.get('head_lr', 0.0) or 0.0)
        backbone_lr = float(self.config.get('backbone_lr', 0.0) or 0.0)
        if head_lr > 0 and backbone_lr > 0 and hasattr(self.model, 'task_heads'):
            head_params = list(self.model.task_heads.parameters())
            head_ids = {id(p) for p in head_params}
            backbone_params = [p for p in self.model.parameters() if id(p) not in head_ids]
            param_groups = [
                {'params': backbone_params, 'lr': backbone_lr, 'initial_lr': backbone_lr},
                {'params': head_params, 'lr': head_lr, 'initial_lr': head_lr},
            ]
            peak_lr = max(backbone_lr, head_lr)
        else:
            param_groups = [
                {'params': self.model.parameters(), 'lr': self.lr, 'initial_lr': self.lr},
            ]
            peak_lr = self.lr
        optimizer = AdamW(param_groups, lr=peak_lr, weight_decay=self.wd)
        warmup = min(10, max(1, self.n_epoch - 1))
        scheduler = CosineAnnealingWarmupRestarts(
            optimizer,
            first_cycle_steps=self.n_epoch,
            max_lr=peak_lr,
            min_lr=float(self.config.get('min_lr', 1e-8)),
            warmup_steps=warmup,
        )
        return [optimizer], [scheduler]

    def lr_scheduler_step(self, scheduler, optimizer_idx):
        scheduler.step()

    def on_train_start(self):
        if not self.loggers:
            return
        # GPT2Config is not OmegaConf-safe; log a JSON-serializable subset.
        safe = {}
        for k, v in self.config.items():
            if k in {'transformer', 'feat_info', 'mean_std'}:
                continue
            if isinstance(v, (str, int, float, bool, list, dict, type(None))):
                safe[k] = v
        try:
            self.loggers[0].log_hyperparams(safe)
        except Exception:
            pass

    def on_train_epoch_start(self):
        if self.n_epoch and self.n_epoch > 0:
            p = self.current_epoch / float(self.n_epoch)
        else:
            p = 0.0
        grl = 2.0 / (1.0 + math.exp(-10.0 * p)) - 1.0
        self.model.set_grl_lambda(grl * self.grl_lambda_max)
        self.log("grl_lambda", float(self.model.grl_lambda),
                 prog_bar=False, rank_zero_only=True)

    def get_progress_bar_dict(self):
        tqdm_dict = super().get_progress_bar_dict()
        tqdm_dict.pop('v_num', None)
        return tqdm_dict

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_multimodal(data):
        return (
            data['cat_feats'],
            data['float_feats'],
            data['valid_mask'],
            data['time_index'],
            data.get('cxr_images', None),
            data.get('cxr_present', None),
            data.get('cohort_id', None),
            data.get('ehr_present', None),
            data.get('cxr_slots', None),
        )

    def _apply_modality_dropout(self, cxr_present, ehr_present):
        """See kidneyformer_pretrain_module.OncoModule._apply_modality_dropout."""
        if not self.training:
            return cxr_present, ehr_present
        p_drop_cxr = self.config.get('p_drop_cxr', 0.25)
        p_drop_ehr = self.config.get('p_drop_ehr', 0.25)
        if cxr_present is None or ehr_present is None:
            return cxr_present, ehr_present
        if cxr_present.shape != ehr_present.shape:
            ehr_b = ehr_present.view(ehr_present.shape[0], *([1] * (cxr_present.dim() - 1)))
            both = cxr_present & ehr_b
        else:
            both = cxr_present & ehr_present
        if not both.any():
            return cxr_present, ehr_present
        device = cxr_present.device
        rand = torch.rand(cxr_present.shape, device=device)
        drop_cxr = both & (rand < p_drop_cxr)
        if cxr_present.shape == ehr_present.shape:
            drop_ehr = both & (rand >= p_drop_cxr) & (rand < p_drop_cxr + p_drop_ehr)
            ehr_present = ehr_present & ~drop_ehr
        return cxr_present & ~drop_cxr, ehr_present

    def _compute_vae_loss(self, vae_losses, prefix='train'):
        vae_loss_total = torch.tensor(0.0, device=self.device)
        vae_weight = self.config.get('vae_loss_weight', 0.1)

        if 'labtest_kl' in vae_losses:
            vae_loss_total = vae_loss_total + vae_losses['labtest_kl'] * vae_weight
            self.log(f"{prefix}_labtest_kl", vae_losses['labtest_kl'],
                     prog_bar=False, rank_zero_only=True, on_epoch=True)
        if 'cxr_kl' in vae_losses:
            vae_loss_total = vae_loss_total + vae_losses['cxr_kl'] * vae_weight
            self.log(f"{prefix}_cxr_kl", vae_losses['cxr_kl'],
                     prog_bar=False, rank_zero_only=True, on_epoch=True)
        if 'symmetric_kl' in vae_losses:
            sym_w = self.config.get('symmetric_kl_weight', 0.1)
            vae_loss_total = vae_loss_total + vae_losses['symmetric_kl'] * sym_w
            self.log(f"{prefix}_symmetric_kl", vae_losses['symmetric_kl'],
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

        return vae_loss_total

    def _compute_adv_losses(self, aux, cat_feats, float_feats, cohort_id,
                            valid_mask, prefix='train'):
        cohort_loss = torch.tensor(0.0, device=self.device)
        miss_loss = torch.tensor(0.0, device=self.device)

        if self.use_cohort_adv and aux.get('cohort_logits') is not None and cohort_id is not None:
            cohort_loss = F.cross_entropy(aux['cohort_logits'], cohort_id)
            self.log(f"{prefix}_cohort_adv_loss", cohort_loss,
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

        if self.use_missingness_adv and aux.get('missingness_logits') is not None:
            miss_target = torch.cat(
                [(cat_feats == -1) | (cat_feats == 256), (float_feats == -1) | (float_feats == 256)], dim=1,
            ).permute(0, 2, 1).contiguous().to(aux['missingness_logits'].dtype)
            miss_logits = aux['missingness_logits']
            per_elem = F.binary_cross_entropy_with_logits(
                miss_logits, miss_target, reduction='none',
            )
            elem_mask = valid_mask.unsqueeze(-1).expand_as(per_elem).float()
            miss_loss = (per_elem * elem_mask).sum() / elem_mask.sum().clamp(min=1)
            self.log(f"{prefix}_missingness_adv_loss", miss_loss,
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

        return cohort_loss * self.cohort_adv_weight + miss_loss * self.missingness_adv_weight

    def _compute_task_loss(self, y_cls, cls_label, cls_mask, reg_label, reg_mask):
        n_cls = cls_label.shape[1]
        n_reg = reg_label.shape[1]

        cls_preds = [y.reshape(-1, y.shape[-1]) for y in y_cls[:n_cls]]
        cls_labels = cls_label.reshape(cls_label.shape[0], n_cls, -1).permute(1, 0, 2)
        cls_labels = [l.reshape(-1) for l in cls_labels]
        cls_masks = cls_mask.reshape(cls_mask.shape[0], n_cls, -1).permute(1, 0, 2)
        cls_masks = [m.reshape(-1) for m in cls_masks]

        cls_loss_terms = []
        for i, (pred, label, mask) in enumerate(zip(cls_preds, cls_labels, cls_masks)):
            per = self.criterion(pred, label)
            if pred.shape[-1] == 2 and self.use_class_weight and i < len(self.class_pos_weight):
                wp = float(self.class_pos_weight[i])
                wn = float(self.class_neg_weight[i]) if i < len(self.class_neg_weight) else 1.0
                per = torch.where(
                    label == 1,
                    per * wp,
                    per * wn,
                )
            if self.pos_loss_boost != 1.0 and pred.shape[-1] == 2:
                per = torch.where(label == 1, per * self.pos_loss_boost, per)
            denom = mask.sum().clip(1)
            cls_loss_terms.append((per * mask).sum() / denom)
        if cls_loss_terms:
            # Mean across heads so the loss scale stays comparable to the
            # previous single-group mean (all heads are binary).
            # Optional per-head weights keep a new head from being diluted.
            stacked = torch.stack(cls_loss_terms)
            hw = self.config.get('cls_loss_weights')
            if hw is not None and len(hw) == stacked.numel():
                w = torch.as_tensor(hw, device=stacked.device, dtype=stacked.dtype)
                cls_loss = (stacked * w).sum() / w.sum().clamp(min=1e-8)
            else:
                cls_loss = stacked.mean()
        else:
            cls_loss = torch.zeros((), device=cls_label.device, dtype=torch.float32)

        if n_reg == 0:
            reg_loss = torch.zeros((), device=cls_label.device, dtype=torch.float32)
        else:
            reg_preds = torch.stack(
                [y_cls[i + n_cls].reshape(-1) for i in range(n_reg)], dim=0,
            )
            reg_labels = (
                reg_label.reshape(reg_label.shape[0], n_reg, -1)
                .permute(1, 0, 2).reshape(n_reg, -1)
            )
            reg_masks = (
                reg_mask.reshape(reg_mask.shape[0], n_reg, -1)
                .permute(1, 0, 2).reshape(n_reg, -1)
            )
            reg_kind = str(self.config.get('reg_loss_type', 'mse')).lower()
            if reg_kind in {'smooth_l1', 'smoothl1', 'huber'}:
                # Prefer smooth_l1_delta; fall back to reg_huber_delta (legacy).
                beta = float(self.config.get(
                    'smooth_l1_delta',
                    self.config.get('reg_huber_delta', 0.5),
                ))
                reg_losses = F.smooth_l1_loss(
                    reg_preds, reg_labels, reduction='none', beta=beta,
                )
            else:
                reg_losses = F.mse_loss(reg_preds, reg_labels, reduction='none')
            # Per-target weights w_k: L = Σ m_ik w_k SmoothL1 / Σ m_ik w_k
            tw = self.config.get('reg_target_weights')
            if tw is None:
                w = torch.ones(n_reg, device=reg_preds.device, dtype=reg_losses.dtype)
            else:
                w = torch.as_tensor(tw, device=reg_preds.device, dtype=reg_losses.dtype)
                if w.numel() != n_reg:
                    raise ValueError(
                        f'reg_target_weights length {w.numel()} != n_reg {n_reg}'
                    )
            w = w.view(n_reg, 1)
            weighted_mask = reg_masks.to(reg_losses.dtype) * w
            eps = 1e-8
            reg_loss = (reg_losses * weighted_mask).sum() / weighted_mask.sum().clamp(min=eps)
            reg_loss = reg_loss * float(self.config.get('reg_loss_weight', 1.0))

        return cls_loss, reg_loss

    def _tx_response_loss(
        self, y_cls, cls_label, cls_mask, reg_label, reg_mask, time_index, tx_base_raw,
    ):
        """Sensitivity prototype / TV / slope / soft-DTW. Inactive unless configured."""
        ref = cls_label
        zeros = {
            'proto': ref.new_zeros(()),
            'tv': ref.new_zeros(()),
            'slope': ref.new_zeros(()),
            'dtw': ref.new_zeros(()),
            'traj': ref.new_zeros(()),
            'reg_scale': 1.0,
        }
        if not self.config.get('tx_response_losses', False):
            return zeros
        heads = self.model.task_heads
        sens_index = getattr(heads, 'guide_index', None)
        n_cls = cls_label.shape[1]
        n_reg = reg_label.shape[1]
        if sens_index is None or n_reg == 0:
            zeros['reg_scale'] = self._tx_reg_scale()
            return zeros
        from tx_response_loss import compute_tx_losses

        reg_pred = torch.stack(
            [y_cls[n_cls + i].squeeze(-1) for i in range(n_reg)], dim=1,
        )
        curve = []
        wanted = set(self.config.get('tx_curve_targets') or ['eGFR', 'UACR'])
        for i, name in enumerate(self.reg_label_names):
            short = str(name).rsplit('_', 1)[-1]
            if short in wanted or name in wanted:
                curve.append(i)
        if not curve:
            curve = list(range(n_reg))
        denorm = {}
        info = self.config.get('reg_label_info') or []
        log_stats = self.config.get('reg_log1p_mean_std') or {}
        winsor = self.config.get('reg_log1p_winsor') or {}
        log_names = set(self.config.get('reg_log1p_cols') or [])
        for i in curve:
            short = str(self.reg_label_names[i]).rsplit('_', 1)[-1]
            if short in log_names and short in log_stats:
                mean, std = log_stats[short]
                denorm[i] = {
                    'mean': float(mean), 'std': float(std), 'log1p': True,
                    'winsor': winsor.get(short),
                }
            elif i < len(info):
                denorm[i] = {
                    'mean': float(info[i][0]), 'std': float(info[i][1]),
                    'log1p': False, 'winsor': None,
                }
        proto_logits = None
        traj_proto = None
        if getattr(heads, 'use_tx_proto', False):
            proto_logits = heads.last_tx.get('proto_logits')
            traj_proto = heads.traj_proto
        losses = compute_tx_losses(
            reg_pred=reg_pred,
            reg_label=reg_label,
            reg_mask=reg_mask,
            time_index=time_index,
            cls_label=cls_label,
            cls_mask=cls_mask,
            sens_index=int(sens_index),
            curve_index=curve,
            proto_logits=proto_logits,
            traj_proto=traj_proto,
            tx_base_raw=tx_base_raw,
            denorm_specs=denorm,
            tv_weight=float(self.config.get('tx_tv_weight', 0.05)),
            slope_weight=float(self.config.get('tx_slope_weight', 0.5)),
            dtw_weight=float(self.config.get('tx_dtw_weight', 0.1)),
            dtw_gamma=float(self.config.get('tx_dtw_gamma', 0.1)),
            proto_weight=float(self.config.get('tx_proto_weight', 0.2)),
            traj_weight=float(self.config.get('tx_traj_proto_weight', 0.1)),
        )
        losses['reg_scale'] = self._tx_reg_scale()
        return losses

    def _tx_reg_scale(self) -> float:
        if not self.config.get('tx_response_losses', False):
            return 1.0
        warm = int(self.config.get('tx_cls_warmup_epochs', 0) or 0)
        if int(getattr(self, 'current_epoch', 0) or 0) < warm:
            return 0.0
        return 1.0

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def training_step(self, batch, batch_idx):
        data = batch['data']
        label = batch['label']
        cls_label = label['cls']['values']
        reg_label = label['reg']['values']

        (cat_feats, float_feats, valid_mask, time_index,
         cxr_images, cxr_present, cohort_id, ehr_present, cxr_slots) = self._extract_multimodal(data)
        cxr_present, ehr_present = self._apply_modality_dropout(cxr_present, ehr_present)

        cls_mask = valid_mask.unsqueeze(1).expand_as(label['cls']['masks']) & label['cls']['masks']
        reg_mask = valid_mask.unsqueeze(1).expand_as(label['reg']['masks']) & label['reg']['masks']
        if self.loss_last_visit_only:
            last = last_valid_visit_mask(valid_mask)  # [B, L]
            cls_mask = cls_mask & last.unsqueeze(1)
            reg_mask = reg_mask & last.unsqueeze(1)

        y_cls, aux = self.model(
            cat_feats, float_feats, valid_mask, time_index,
            cxr_images=cxr_images, cxr_present=cxr_present, ehr_present=ehr_present,
            cxr_slots=cxr_slots,
        )

        cls_loss, reg_loss = self._compute_task_loss(
            y_cls, cls_label, cls_mask, reg_label, reg_mask,
        )
        tx = self._tx_response_loss(
            y_cls, cls_label, cls_mask, reg_label, reg_mask, time_index,
            label.get('tx_base_raw'),
        )
        reg_scale = tx.pop('reg_scale')
        vae_loss = self._compute_vae_loss(aux['vae'], prefix='train')
        adv_loss = self._compute_adv_losses(
            aux, cat_feats, float_feats, cohort_id, valid_mask, prefix='train',
        )

        # Task loss dominates; aux terms are lightly regularised for AP-focused runs.
        vae_w = float(self.config.get('vae_loss_weight', 0.1))
        # _compute_vae_loss already scales internally in some setups; keep additive as before
        loss = cls_loss + tx['proto'] + reg_scale * (
            reg_loss + tx['tv'] + tx['slope'] + tx['dtw'] + tx['traj']
        ) + vae_loss + adv_loss
        self.log("train_loss", loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_cls_loss", cls_loss, prog_bar=True, rank_zero_only=True, on_epoch=True)
        self.log("train_reg_loss", reg_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_tx_proto", tx['proto'], prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_tx_tv", tx['tv'], prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_tx_slope", tx['slope'], prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_tx_dtw", tx['dtw'], prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_tx_traj", tx['traj'], prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_vae_loss", vae_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_adv_loss", adv_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        return loss

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def on_validation_epoch_start(self) -> None:
        self.preds = defaultdict(list)
        self.targets = defaultdict(list)

    def _ablation_modes_this_epoch(self):
        """See kidneyformer_pretrain_module.OncoModule._ablation_modes_this_epoch.
        OFF by default; enable via ``ablation_every_n_epochs`` in the config.
        """
        modes = [('', None, None, False)]
        every = int(self.config.get('ablation_every_n_epochs', 0))
        if every <= 0:
            return modes
        run_ablation = (every == 1) or ((self.current_epoch + 1) % every == 0)
        if run_ablation:
            modes.append(('ehr_only_', 'off', None, False))
            modes.append(('img_only_', None, 'off', True))
        return modes

    def validation_step(self, batch, batch_idx):
        fused_loss = None
        for prefix, cxr_override, ehr_override, subset_cxr in self._ablation_modes_this_epoch():
            loss = self._run_val_pass(
                batch, prefix=prefix,
                cxr_override=cxr_override, ehr_override=ehr_override,
                subset_cxr=subset_cxr,
            )
            if prefix == '':
                fused_loss = loss
        return fused_loss

    def _run_val_pass(self, batch, *, prefix, cxr_override, ehr_override, subset_cxr):
        """One validation forward at the requested modality configuration. See
        the pretrain module's identical helper for prefix semantics."""
        data = batch['data']
        label = batch['label']

        (cat_feats, float_feats, valid_mask, time_index,
         cxr_images, cxr_present, cohort_id, ehr_present, cxr_slots) = self._extract_multimodal(data)

        keep_idx = None
        if subset_cxr:
            if cxr_present is None or not cxr_present.any():
                return None
            keep_idx = cxr_present.nonzero(as_tuple=True)[0]

        def _slice(t):
            if t is None or keep_idx is None:
                return t
            return t[keep_idx]

        cat_feats = _slice(cat_feats)
        float_feats = _slice(float_feats)
        valid_mask = _slice(valid_mask)
        time_index = _slice(time_index)
        cxr_images = _slice(cxr_images)
        cxr_present = _slice(cxr_present)
        ehr_present = _slice(ehr_present)
        cohort_id = _slice(cohort_id)
        cls_label = _slice(label['cls']['values'])
        cls_mask_full = _slice(label['cls']['masks'])
        reg_label = _slice(label['reg']['values'])
        reg_mask_full = _slice(label['reg']['masks'])

        if cxr_override == 'off' and cxr_present is not None:
            cxr_present = torch.zeros_like(cxr_present)
        if ehr_override == 'off' and ehr_present is not None:
            ehr_present = torch.zeros_like(ehr_present)

        cls_mask = valid_mask.unsqueeze(1).expand_as(cls_mask_full) & cls_mask_full
        reg_mask = valid_mask.unsqueeze(1).expand_as(reg_mask_full) & reg_mask_full
        if self.loss_last_visit_only:
            last = last_valid_visit_mask(valid_mask)
            cls_mask = cls_mask & last.unsqueeze(1)
            reg_mask = reg_mask & last.unsqueeze(1)

        y_cls, aux = self.model(
            cat_feats, float_feats, valid_mask, time_index,
            cxr_images=cxr_images, cxr_present=cxr_present, ehr_present=ehr_present,
            cxr_slots=cxr_slots,
        )
        n_cls = cls_label.shape[1]

        cls_loss, reg_loss = self._compute_task_loss(
            y_cls, cls_label, cls_mask, reg_label, reg_mask,
        )
        tx_base = label.get('tx_base_raw')
        if tx_base is not None and keep_idx is not None:
            tx_base = tx_base[keep_idx]
        tx = self._tx_response_loss(
            y_cls, cls_label, cls_mask, reg_label, reg_mask, time_index, tx_base,
        )
        reg_scale = tx.pop('reg_scale')
        if prefix == '':
            vae_loss = self._compute_vae_loss(aux['vae'], prefix='val')
            adv_loss = self._compute_adv_losses(
                aux, cat_feats, float_feats, cohort_id, valid_mask, prefix='val',
            )
            loss = cls_loss + tx['proto'] + reg_scale * (
                reg_loss + tx['tv'] + tx['slope'] + tx['dtw'] + tx['traj']
            ) + vae_loss + adv_loss
            self.log("val_loss", loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
            self.log("val_tx_proto", tx['proto'], prog_bar=False, rank_zero_only=True, on_epoch=True)
        else:
            loss = cls_loss + tx['proto'] + reg_scale * (
                reg_loss + tx['tv'] + tx['slope'] + tx['dtw'] + tx['traj']
            )

        tensor_to_gather = [
            cls_label.contiguous(), cls_mask.contiguous(),
            reg_label.contiguous(), reg_mask.contiguous(),
        ] + [t.contiguous() for t in y_cls]
        if dist.is_initialized():
            tensor_gathered = [x.cpu() for x in all_gather(tensor_to_gather)]
        else:
            tensor_gathered = [x.cpu() for x in tensor_to_gather]
        cls_label, cls_mask, reg_label, reg_mask = tensor_gathered[:4]
        y_cls = tensor_gathered[4:]

        for i in range(len(self.cls_label_names)):
            mask = cls_mask[:, i, :]
            pp = y_cls[i][mask]
            pp = torch.softmax(pp, dim=-1)
            yy = cls_label[:, i, :][mask]
            if len(pp) > 0:
                self.preds[f'{prefix}cls_{i}'].append(pp)
                self.targets[f'{prefix}cls_{i}'].append(yy)

        for i in range(len(self.reg_label_names)):
            mask = reg_mask[:, i, :]
            pp = y_cls[i + n_cls].squeeze(-1)[mask]
            yy = reg_label[:, i, :][mask]
            if len(pp) > 0:
                self.preds[f'{prefix}reg_{i}'].append(pp)
                self.targets[f'{prefix}reg_{i}'].append(yy)

        return loss

    def on_validation_epoch_end(self) -> None:
        prefixes = sorted({k.rsplit('cls_', 1)[0].rsplit('reg_', 1)[0]
                            for k in self.preds.keys()})

        fused_mauc = None
        for prefix in prefixes:
            mauc, mf1, map_, macc, msen, mspe = [], [], [], [], [], []
            for i, k in enumerate(self.cls_label_names):
                key = f'{prefix}cls_{i}'
                if not self.preds[key]:
                    if prefix == '':
                        self.log(f"val_{k}_auc", torch.nan,
                                 prog_bar=False, rank_zero_only=True)
                    continue
                pred = dim_zero_cat(self.preds[key]).float()
                target = dim_zero_cat(self.targets[key])
                if pred.shape[-1] == 2:
                    pred = pred[..., 1]
                    y_np = target.numpy()
                    p_np = pred.numpy()
                    precision, recall, thresholds = precision_recall_curve(
                        y_np, p_np,
                    )
                    precision = precision + 1e-10
                    recall = recall + 1e-10
                    f1 = 2 * recall * precision / (recall + precision)
                    best_f1 = float(np.max(f1))
                    mf1.append(best_f1)
                    auc = MF.auroc(pred, target, task='binary')
                    # Operating point at 0.5 for ACC / SEN / SPE / AP
                    pred_bin = (pred >= 0.5).long()
                    tp = ((pred_bin == 1) & (target == 1)).sum().float()
                    tn = ((pred_bin == 0) & (target == 0)).sum().float()
                    fp = ((pred_bin == 1) & (target == 0)).sum().float()
                    fn = ((pred_bin == 0) & (target == 1)).sum().float()
                    acc = (tp + tn) / (tp + tn + fp + fn + 1e-10)
                    sen = tp / (tp + fn + 1e-10)
                    spe = tn / (tn + fp + 1e-10)
                    try:
                        ap = float(average_precision_score(y_np, p_np))
                    except Exception:
                        ap = float('nan')
                    self.log(f"val_{prefix}{k}_auc", auc,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_f1", best_f1,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_ap", ap,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_acc", acc,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_sen", sen,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_spe", spe,
                             prog_bar=False, rank_zero_only=True)
                    mauc.append(auc)
                    if np.isfinite(ap):
                        map_.append(ap)
                    macc.append(float(acc))
                    msen.append(float(sen))
                    mspe.append(float(spe))
                else:
                    num_classes = pred.shape[-1]
                    top1_acc = MF.accuracy(
                        pred, target, task='multiclass',
                        num_classes=num_classes, top_k=1,
                    )
                    top5_acc = MF.accuracy(
                        pred, target, task='multiclass',
                        num_classes=num_classes, top_k=5,
                    )
                    target_onehot = label_binarize(
                        target.numpy(), classes=range(num_classes))
                    micro_auc = roc_auc_score(
                        target_onehot.ravel(), pred.numpy().ravel())
                    self.log(f"val_{prefix}{k}_top1_acc", top1_acc,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_top5_acc", top5_acc,
                             prog_bar=False, rank_zero_only=True)
                    self.log(f"val_{prefix}{k}_micro_auc", micro_auc,
                             prog_bar=False, rank_zero_only=True)

            if mauc:
                mean_auc = sum(mauc) / len(mauc)
                self.log(f"val_{prefix}mauc", mean_auc,
                         prog_bar=(prefix == ''), rank_zero_only=True)
                if prefix == '':
                    fused_mauc = mean_auc
            if mf1:
                self.log(f"val_{prefix}mf1", sum(mf1) / len(mf1),
                         prog_bar=False, rank_zero_only=True)
            if map_:
                self.log(f"val_{prefix}map", sum(map_) / len(map_),
                         prog_bar=False, rank_zero_only=True)
            if macc:
                self.log(f"val_{prefix}macc", sum(macc) / len(macc),
                         prog_bar=False, rank_zero_only=True)
            if msen:
                self.log(f"val_{prefix}msen", sum(msen) / len(msen),
                         prog_bar=False, rank_zero_only=True)
            if mspe:
                self.log(f"val_{prefix}mspe", sum(mspe) / len(mspe),
                         prog_bar=False, rank_zero_only=True)

        mpcc = []
        mr2 = []
        core_r2 = []
        core_targets = {
            str(x) for x in (self.config.get('reg_core_targets') or [])
        }

        def _reg_short(name: str) -> str:
            for prefix in ('c_reg_labels_', 'f_reg_labels_', 'reg_labels_'):
                if name.startswith(prefix):
                    return name[len(prefix):]
            return name.split('_')[-1]

        for i, k in enumerate(self.reg_label_names):
            if not self.preds[f'reg_{i}']:
                continue
            pred = dim_zero_cat(self.preds[f'reg_{i}']).double()
            target = dim_zero_cat(self.targets[f'reg_{i}']).double()
            if pred.numel() < 2:
                continue
            self.log(f"val_{k}_mse", MF.mean_squared_error(pred, target),
                     prog_bar=False, rank_zero_only=True)
            try:
                pcc = MF.pearson_corrcoef(pred, target)
                self.log(f"val_{k}_pcc", pcc, prog_bar=False, rank_zero_only=True)
                if torch.isfinite(pcc):
                    mpcc.append(pcc)
            except Exception:
                pass
            try:
                r2 = MF.r2_score(pred, target)
                self.log(f"val_{k}_r2", r2, prog_bar=False, rank_zero_only=True)
                if torch.isfinite(r2):
                    mr2.append(r2)
                    short = _reg_short(k)
                    # Empty core list → keep legacy behaviour (all targets).
                    if (not core_targets) or (short in core_targets):
                        core_r2.append(r2)
            except Exception:
                pass

        if mpcc:
            self.log("val_mpcc", sum(mpcc) / len(mpcc), prog_bar=False, rank_zero_only=True)
        mean_r2 = (sum(mr2) / len(mr2)) if mr2 else None
        if mean_r2 is not None:
            self.log("val_mean_r2", mean_r2, prog_bar=False, rank_zero_only=True)
        core_mean_r2 = (sum(core_r2) / len(core_r2)) if core_r2 else mean_r2
        if core_mean_r2 is not None:
            self.log(
                "val_core_mean_r2", core_mean_r2,
                prog_bar=False, rank_zero_only=True,
            )
        # Composite for early-stop / ckpt: val_mauc + λ * val_core_mean_r2
        combo_w = float(self.config.get('early_stop_r2_weight', 0.0) or 0.0)
        if combo_w > 0 and fused_mauc is not None:
            r2_term = float(core_mean_r2) if core_mean_r2 is not None else 0.0
            self.log(
                "val_mauc_r2",
                float(fused_mauc) + combo_w * r2_term,
                prog_bar=True,
                rank_zero_only=True,
            )

    # ------------------------------------------------------------------
    # Testing
    # ------------------------------------------------------------------

    def on_test_epoch_start(self) -> None:
        self.test_outputs = []

    def test_step(self, batch, batch_idx):
        data = batch['data']
        pid = batch['pid']
        label = batch['label']
        cls_label = label['cls']['values']
        reg_label = label['reg']['values']

        (cat_feats, float_feats, valid_mask, time_index,
         cxr_images, cxr_present, _, ehr_present, cxr_slots) = self._extract_multimodal(data)

        cls_mask = valid_mask.unsqueeze(1).expand_as(label['cls']['masks']) & label['cls']['masks']
        reg_mask = valid_mask.unsqueeze(1).expand_as(label['reg']['masks']) & label['reg']['masks']
        if self.loss_last_visit_only:
            last = last_valid_visit_mask(valid_mask)
            cls_mask = cls_mask & last.unsqueeze(1)
            reg_mask = reg_mask & last.unsqueeze(1)

        y_cls, _aux = self.model(
            cat_feats, float_feats, valid_mask, time_index,
            cxr_images=cxr_images, cxr_present=cxr_present, ehr_present=ehr_present,
            cxr_slots=cxr_slots,
        )

        self.test_outputs.append({
            'pid': list(pid) if not torch.is_tensor(pid) else pid.detach().cpu(),
            'preds': [t.cpu() for t in y_cls],
            'cls_label': cls_label.cpu(),
            'cls_mask': cls_mask.cpu(),
            'reg_label': reg_label.cpu(),
            'reg_mask': reg_mask.cpu(),
        })

    def on_test_epoch_end(self):
        output_dir = Path(self.output_dir) / self.pred_folder
        output_dir.mkdir(parents=True, exist_ok=True)

        n_cls = len(self.cls_label_names)
        n_reg = len(self.reg_label_names)

        pred_cls = [[] for _ in range(n_cls)]
        cls_mask_all = [[] for _ in range(n_cls)]
        cls_label_all = [[] for _ in range(n_cls)]
        for out in self.test_outputs:
            for j in range(n_cls):
                pred_cls[j].append(out['preds'][j])
                cls_mask_all[j].append(out['cls_mask'][:, j, :])
                cls_label_all[j].append(out['cls_label'][:, j, :])

        pred_cls = [torch.softmax(torch.cat(x, dim=0).float(), dim=-1) for x in pred_cls]
        cls_mask_all = [torch.cat(x, dim=0) for x in cls_mask_all]
        cls_label_all = [torch.cat(x, dim=0) for x in cls_label_all]

        pred_reg = [[] for _ in range(n_reg)]
        reg_mask_all = [[] for _ in range(n_reg)]
        reg_label_all = [[] for _ in range(n_reg)]
        for out in self.test_outputs:
            for j in range(n_reg):
                pred_reg[j].append(out['preds'][j + n_cls])
                reg_mask_all[j].append(out['reg_mask'][:, j, :])
                reg_label_all[j].append(out['reg_label'][:, j, :])

        # cast to float32: bf16-mixed leaves Softmax/preds as BFloat16 which
        # cannot be converted via Tensor.numpy()
        pred_reg = [torch.cat(x, dim=0).float() for x in pred_reg]
        reg_mask_all = [torch.cat(x, dim=0).float() for x in reg_mask_all]
        reg_label_all = [torch.cat(x, dim=0).float() for x in reg_label_all]

        pid_chunks = [x['pid'] for x in self.test_outputs]
        if pid_chunks and torch.is_tensor(pid_chunks[0]):
            pid = torch.cat(pid_chunks).numpy()
        else:
            pid = []
            for chunk in pid_chunks:
                pid.extend(list(chunk))
        n_sample = len(pid)

        df = pd.DataFrame({'pid': pid})
        for i, col in enumerate(tqdm(self.cls_label_names)):
            if pred_cls[i].shape[-1] == 2:
                tmp1 = pd.DataFrame(
                    [{f"{col}_prob_1": pred_cls[i][j, :, 1].numpy()} for j in range(n_sample)],
                )
                tmp2 = pd.DataFrame(
                    [{f"{col}_mask": cls_mask_all[i][j, :].numpy()} for j in range(n_sample)],
                )
                tmp3 = pd.DataFrame(
                    [{col: cls_label_all[i][j, :].numpy()} for j in range(n_sample)],
                )
            else:
                tmp1 = pd.DataFrame(
                    [{f"{col}_probs": batch_top5_encode(
                        pred_cls[i][j, :, :].numpy().astype(np.int32),
                    )} for j in range(n_sample)],
                )
                tmp2 = pd.DataFrame(
                    [{f"{col}_mask": cls_mask_all[i][j, :].numpy()} for j in range(n_sample)],
                )
                tmp3 = pd.DataFrame(
                    [{col: cls_label_all[i][j, :].numpy()} for j in range(n_sample)],
                )
            df = pd.concat([df, tmp1, tmp2, tmp3], axis=1)

        for i, col in enumerate(self.reg_label_names):
            tmp1 = pd.DataFrame(
                [{f"{col}_prob_0": pred_reg[i][j, :, 0].numpy()} for j in range(n_sample)],
            )
            tmp2 = pd.DataFrame(
                [{f"{col}_mask": reg_mask_all[i][j, :].numpy()} for j in range(n_sample)],
            )
            tmp3 = pd.DataFrame(
                [{col: reg_label_all[i][j, :].numpy()} for j in range(n_sample)],
            )
            df = pd.concat([df, tmp1, tmp2, tmp3], axis=1)

        output_path = output_dir / f'test_pred.{self.global_rank}.parquet'
        df.to_parquet(output_path)
        self.test_outputs.clear()
        gc.collect()
