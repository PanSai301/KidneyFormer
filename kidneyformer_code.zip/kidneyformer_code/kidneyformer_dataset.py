import gc
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import pytorch_lightning as pl
import torch
import torchvision.transforms as transforms
from PIL import Image
from torch.utils.data import DataLoader, Dataset, default_collate

from Utils import load_parquet

_MP_CONTEXT = None if sys.platform == 'win32' else 'fork'


def optimize_dtypes(df):
    for col in df.columns:
        if pd.api.types.is_integer_dtype(df[col]):
            col_min, col_max = df[col].min(), df[col].max()
            
            if col_min >= 0:
                if col_max < 2**8:
                    df[col] = df[col].astype(np.uint8)
                elif col_max < 2**16:
                    df[col] = df[col].astype(np.uint16)
                elif col_max < 2**32:
                    df[col] = df[col].astype(np.uint32)
            else:
                if col_min > -2**7 and col_max < 2**7:
                    df[col] = df[col].astype(np.int8)
                elif col_min > -2**15 and col_max < 2**15:
                    df[col] = df[col].astype(np.int16)
                elif col_min > -2**31 and col_max < 2**31:
                    df[col] = df[col].astype(np.int32)
        
        elif pd.api.types.is_float_dtype(df[col]):
            df[col] = df[col].astype(np.float32)
            
        elif pd.api.types.is_string_dtype(df[col]) and df[col].nunique() / len(df[col]) < 0.5:
            df[col] = df[col].astype('category')
            
    return df

def sample_subset(mask, prob):
    """Sample subset of valid indices for masking, following original logic"""
    valid_indices = np.where(mask)[0]
    if len(valid_indices) == 0:
        return np.array([], dtype=int), np.array([], dtype=int)
    
    n_total = len(valid_indices)
    n_output = max(1, int(n_total * prob))
    
    # Randomly select indices for output (masked prediction)
    output_indices = np.random.choice(valid_indices, size=n_output, replace=False)
    
    # Remaining indices are for input
    input_indices = np.setdiff1d(valid_indices, output_indices)
    
    return input_indices, output_indices

class CXRImageProcessor:
    """Stateless CXR loader returning a fixed-shape (tensor, present) pair.

    The dataframe carries the absolute path to each patient's CXR (column
    ``xray_path``); if the path is empty or unreadable we emit zeros plus
    ``present=False`` so the model can gate the image contribution. There is
    NO in-process cache — at COMPASS scale the cache would dwarf RAM, and
    the OS page cache already handles repeated reads of the same file.

    When ``train=True`` we apply mild geometric and photometric augmentation
    (the rotations / flips / brightness jitter described in the manuscript
    Methods); validation and test passes always use the deterministic
    Resize + Normalize pipeline so val metrics are reproducible.
    """

    def __init__(self, img_size=518, img_data_dir=None, train=False,
                 rotation_deg=10.0, brightness=0.2, contrast=0.0,
                 hflip_prob=0.5, mean=None, std=None):
        self.img_size = img_size
        self.train = bool(train)
        # Optional prefix prepended to relative xray_path values.
        self.img_data_dir = Path(img_data_dir) if img_data_dir else None
        if mean is None:
            mean = [0.485, 0.456, 0.406]
        if std is None:
            std = [0.229, 0.224, 0.225]
        if isinstance(mean, (int, float)):
            mean = [mean, mean, mean]
        if isinstance(std, (int, float)):
            std = [std, std, std]
        normalize = transforms.Normalize(mean=list(mean), std=list(std))
        resize = transforms.Resize((img_size, img_size))
        if self.train:
            self.transform = transforms.Compose([
                resize,
                transforms.RandomHorizontalFlip(p=hflip_prob),
                transforms.RandomRotation(
                    degrees=rotation_deg,
                    interpolation=transforms.InterpolationMode.BILINEAR,
                ),
                transforms.ColorJitter(brightness=brightness, contrast=contrast),
                transforms.ToTensor(),
                normalize,
            ])
        else:
            self.transform = transforms.Compose([
                resize, transforms.ToTensor(), normalize,
            ])
        self._zero = torch.zeros(3, img_size, img_size, dtype=torch.float32)

    def _resolve(self, path):
        if not path:
            return None
        p = Path(path)
        if not p.is_absolute() and self.img_data_dir is not None:
            p = self.img_data_dir / p
        return p

    def _load_one(self, path):
        try:
            resolved = self._resolve(path)
            if resolved is None or not resolved.exists():
                return None
            if resolved.suffix == '.npy':
                arr = np.load(resolved)
                image = Image.fromarray(arr.astype(np.uint8), mode='L').convert('RGB')
            else:
                image = Image.open(resolved).convert('RGB')
            return self.transform(image)
        except Exception:
            return None

    def load_image_with_presence(self, path):
        image = self._load_one(path)
        if image is None:
            return self._zero, False
        return image, True

    def load_visit_images(self, paths):
        """Load one film per visit. Missing visits stay out of the image batch."""
        paths = list(paths) if paths is not None else []
        present_at = []
        images = []
        for t, path in enumerate(paths):
            if not path:
                continue
            image = self._load_one(path)
            if image is None:
                continue
            images.append(image)
            present_at.append(t)
        length = max(len(paths), 1)
        present = torch.zeros(length, dtype=torch.bool)
        if images:
            present[present_at] = True
            stacked = torch.stack(images, dim=0)
            times = torch.tensor(present_at, dtype=torch.long)
        else:
            stacked = torch.zeros(0, 3, self.img_size, self.img_size)
            times = torch.zeros(0, dtype=torch.long)
        return stacked, times, present


# Columns that store per-patient arrays (1-D or 2-D). At setup time we
# pre-convert each of these from the parquet's nested-list-of-arrays
# representation into a single flat ndarray indexed by patient row, so
# __getitem__ is a plain array slice — no per-row np.asarray() on the hot
# path. This is the biggest single win for DataLoader throughput.
_ARRAY_COLS_2D = (
    'tokenized_category_feats', 'tokenized_float_feats',
    'category_feats', 'float_feats',
    'c_cls_labels', 'f_cls_labels', 'c_reg_labels',
)
_ARRAY_COLS_1D = ('valid_mask', 'time_index')


def _preload_arrays(df, cols_2d=_ARRAY_COLS_2D, cols_1d=_ARRAY_COLS_1D):
    """Materialize 1-D / 2-D array columns into contiguous ndarrays.

    The parquet round-trip stores each cell as an object-ndarray of inner
    ndarrays. For a 2-D column the cell shape is (n_feat,), where each
    element is a 1-D ndarray of length seq_len. We flatten that into a single
    (N_rows, n_feat, seq_len) ndarray once at setup so per-sample reads are
    O(1) slice views — eliminating ~6 np.asarray calls from every
    __getitem__ on the hot DataLoader path.
    """
    out = {}
    for c in cols_2d:
        if c not in df.columns:
            continue
        first = df[c].iloc[0]
        n_feat = len(first)
        seq_len = len(first[0])
        # Determine dtype from the first inner array; parquet preserves it.
        dtype = np.asarray(first[0]).dtype
        # Two-pass build via np.stack: first stack each row's inner arrays
        # (cheap C op on n_feat=~28 elements), then stack all rows.
        rows = [np.stack(r, axis=0) for r in df[c].values]
        out[c] = np.stack(rows, axis=0).astype(dtype, copy=False)
        assert out[c].shape == (len(df), n_feat, seq_len)
    for c in cols_1d:
        if c not in df.columns:
            continue
        first = df[c].iloc[0]
        dtype = np.asarray(first).dtype
        out[c] = np.stack([np.asarray(r) for r in df[c].values], axis=0).astype(dtype, copy=False)
        return out


_FINETUNE_CACHE_COLS = (
    'tokenized_category_feats', 'tokenized_float_feats',
    'c_cls_labels', 'f_cls_labels', 'valid_mask', 'time_index',
)
_PRETRAIN_CACHE_COLS = (
    'tokenized_category_feats', 'tokenized_float_feats',
    'category_feats', 'float_feats', 'valid_mask', 'time_index',
)


def array_cache_dir(df_path, split):
    return Path(df_path) / 'array_cache' / split


def array_cache_ready(df_path, mode='finetune'):
    root = Path(df_path)
    if mode == 'pretrain':
        needed = list(_PRETRAIN_CACHE_COLS)
    else:
        needed = [
            'tokenized_category_feats', 'tokenized_float_feats',
            'valid_mask', 'time_index',
        ]
    for s in ('train', 'valid', 'test'):
        d = root / 'array_cache' / s
        if not (d / 'DONE').exists():
            return False
        for c in needed:
            if not (d / f'{c}.npy').exists():
                return False
        if mode != 'pretrain':
            if not ((d / 'c_cls_labels.npy').exists() or (d / 'f_cls_labels.npy').exists()):
                return False
    return True


def load_array_cache(cache_dir, pid_col, disease_names):
    """Load pre-materialized arrays via mmap (shared across DDP ranks)."""
    cache_dir = Path(cache_dir)
    pre = {}
    pids = None
    cohort = None
    xray = None
    for p in sorted(cache_dir.glob('*.npy')):
        if p.stem == 'pids':
            pids = np.load(p, allow_pickle=True)
        elif p.stem == 'cohort_id':
            cohort = np.load(p, allow_pickle=True)
        elif p.stem == 'xray_paths':
            xray = np.load(p, allow_pickle=True)
        else:
            pre[p.stem] = np.load(p, mmap_mode='r')
    if pids is None:
        raise FileNotFoundError(f'pids.npy missing in {cache_dir}')
    data = {pid_col: pids}
    if cohort is not None:
        data['cohort_id'] = cohort
    df = pd.DataFrame(data)
    if xray is not None:
        df['xray_paths'] = [xray[i] for i in range(len(xray))]
    if disease_names:
        df['diag_cols'] = None
        df.iat[0, df.columns.get_loc('diag_cols')] = list(disease_names)
    return df, pre


@dataclass
class ChunkedOncoDataset(Dataset):
    data_chunks: list
    mode: str
    config: dict
    preload_arrays: list | None = None

    def __post_init__(self):
        self.df_paths = self.config['df_paths']
        self.chunk_lengths = [len(chunk) for chunk in self.data_chunks]
        self.cumulative_lengths = np.cumsum(self.chunk_lengths)
        self.total_length = self.cumulative_lengths[-1] if self.chunk_lengths else 0

        self.use_img_model = self.config.get('use_img_model', False)
        if self.use_img_model:
            # Augmentation only applies in the train split; val/test always
            # see the deterministic Resize+Normalize pipeline. Strength is
            # configurable so the augmentation can be turned off for ablations
            # by setting ``cxr_augment: false`` or by tuning the magnitudes.
            cxr_aug = self.config.get('cxr_augment', True)
            train_aug = cxr_aug and (self.mode == 'train')
            aug_cfg = self.config.get('cxr_augment_params', {})
            self.img_processor = CXRImageProcessor(
                img_size=self.config.get('img_size', 518),
                img_data_dir=self.config.get('img_data_dir'),
                train=train_aug,
                rotation_deg=aug_cfg.get('rotation_deg', 10.0),
                brightness=aug_cfg.get('brightness', 0.2),
                contrast=aug_cfg.get('contrast', 0.0),
                hflip_prob=aug_cfg.get('hflip_prob', 0.5),
                mean=self.config.get('cxr_mean'),
                std=self.config.get('cxr_std'),
            )

        # Cohort label source for the adversarial cohort discriminator.
        # Falls back to a single-cohort label (0) when the column is absent.
        self.cohort_col = self.config.get('cohort_col', 'cohort_id')

        # Patient-id column. The published demo data renames ``pid`` ->
        # ``demo_patient_id``; auto-detect so either schema loads unchanged.
        cols0 = set(self.data_chunks[0].columns) if self.data_chunks else set()
        self.pid_col = self.config.get(
            'pid_col', 'demo_patient_id' if 'demo_patient_id' in cols0 else 'pid')

        self._setup_config()

        # Pre-materialize array columns. Done after _setup_config so we can
        # gate on having data and skip empty chunks. Under Linux fork-mode
        # DataLoader workers, these arrays are shared (copy-on-write) with
        # the parent, so they cost RAM only once across all workers.
        # Finetune only needs tokenized_* + labels; skip raw float/category
        # feats to roughly halve RAM on large cohorts.
        cols_2d = _ARRAY_COLS_2D
        if self.config.get('mode') == 'finetune':
            cols_2d = tuple(
                c for c in _ARRAY_COLS_2D
                if c not in ('float_feats', 'category_feats')
            )
        if self.preload_arrays is not None:
            self._preloaded = self.preload_arrays
        else:
            self._preloaded = [
                _preload_arrays(chunk, cols_2d=cols_2d) for chunk in self.data_chunks
            ]

    def _setup_config(self):
        self.dataframe_cols = set().union(*[set(c.columns) for c in self.data_chunks])
        self.seq_max_len = self.config['seq_max_len']
        self.config['cls_label_names'] = []
        self.config['reg_label_names'] = []
        self.config['n_cls'] = []

        if self.config.get('mode') == 'pretrain':
            if 'feat_info' not in self.config:
                raise ValueError("feat_info required for pretraining mode")
            feat_info = self.config['feat_info']
            self.cls_label_names = list(feat_info['category_cols'])
            # Arrays are packed in FLOAT_NAMES / feat_info insertion order.
            # Do NOT sort — that misaligns mean_std with float_feats channels.
            self.reg_label_names = list(feat_info['float_cols'].keys())
            self.mean_std = np.array(
                [(feat_info['float_cols'][x]['mean'], feat_info['float_cols'][x]['std'])
                 for x in self.reg_label_names],
                dtype=np.float32,
            )
            self.config['cls_label_names'] = self.cls_label_names
            self.config['reg_label_names'] = self.reg_label_names
            self.config['mean_std'] = self.mean_std
            self.mask_ratio = self.config.get('mask_ratio', 0.5)
            self.visit_mask_ratio = float(self.config.get('visit_mask_ratio', 0.0))
            self.log1p_float_idx = [
                i for i, name in enumerate(self.reg_label_names)
                if name in set(self.config.get('log1p_float_cols') or [])
            ]
            self._apply_log1p_mean_std()
            return

        # Finetune mode: pull per-task labels from the first row's name lists.
        first_row = self.data_chunks[0].iloc[0]
        for label_col, name_col, n_cls in zip(
            self.config['cls_label_cols'],
            self.config['cls_label_name_cols'],
            self.config['cls_label_n_cls'],
        ):
            for name in first_row[name_col]:
                self.config['cls_label_names'].append(f'{label_col}_{name}')
                self.config['n_cls'].append(n_cls)
        for label_col, name_col in zip(
            self.config.get('reg_label_cols', []),
            self.config.get('reg_label_name_cols', []),
        ):
            for name in first_row[name_col]:
                self.config['reg_label_names'].append(f'{label_col}_{name}')
                self.config['n_cls'].append(1)

    def _apply_log1p_mean_std(self):
        """Replace z-score stats for heavy-tailed labs after log1p(x)."""
        if not self.log1p_float_idx:
            return
        preset = self.config.get('log1p_mean_std') or {}
        for i in self.log1p_float_idx:
            name = self.reg_label_names[i]
            if name in preset:
                mu, sd = preset[name]
                self.mean_std[i, 0] = float(mu)
                self.mean_std[i, 1] = max(float(sd), 1e-6)
        self.config['mean_std'] = self.mean_std

    def _runtime_slice(self, valid_mask: np.ndarray) -> slice:
        """Return the slice that keeps the most-recent ``seq_max_len`` valid
        visits for this sample.

        The preprocessed parquet packs valid visits at positions [0, n_valid)
        and right-pads to ``preprocessed_seq_max_len`` (usually 64). At
        runtime the model may be configured with a smaller ``seq_max_len``
        (e.g. 16); we then either:
          - shrink to ``[0, seq_max_len)`` for short patients (kept padding
            tail is harmless — masked by ``valid_mask``); or
          - shrink to ``[n_valid - seq_max_len, n_valid)`` for long patients,
            preserving the most recent visits (the clinically meaningful
            ones for diagnosis / prediction).

        Without this slice, GPT-2's positional embedding (sized to
        ``seq_max_len``) gets indexed up to the preprocessed sequence
        length and overflows.
        """
        n_valid = int(valid_mask.sum())
        L = valid_mask.shape[-1]
        target = self.seq_max_len
        if L <= target:
            return slice(0, L)
        if n_valid <= target:
            return slice(0, target)
        return slice(n_valid - target, n_valid)

    def read_col(self, chunk_idx: int, within_chunk_idx: int, _data, col: str):
        """Return the column value for a (chunk, row). Hits the preloaded
        contiguous ndarray for 1-D/2-D array columns and falls back to the
        per-row parquet cell for scalars (pid, cohort_id, xray_path …).

        Array columns are sliced along their last (sequence) axis by the
        runtime slice stashed on ``self._current_slice`` in ``__getitem__``,
        so every read returns an exactly ``seq_max_len``-long window.

        The unused ``_data`` arg is a vestige of the (now-removed) diskcache
        path; keeping it lets every caller stay one-line.
        """
        pre = self._preloaded[chunk_idx].get(col)
        if pre is not None:
            arr = pre[within_chunk_idx]
            slc = getattr(self, '_current_slice', None)
            if slc is not None and arr.ndim >= 1 and arr.shape[-1] > (slc.stop - slc.start):
                arr = arr[..., slc]
            return arr
        return self.data_chunks[chunk_idx].iloc[within_chunk_idx][col]

    def _get_cohort_id(self, chunk_idx, within_chunk_idx, data):
        if self.cohort_col in self.dataframe_cols:
            return int(self.read_col(chunk_idx, within_chunk_idx, data, self.cohort_col))
        return 0

    def _get_xray_path(self, chunk_idx, within_chunk_idx, data):
        col = self.config.get('xray_path_col', 'xray_path')
        if col in self.dataframe_cols:
            v = self.read_col(chunk_idx, within_chunk_idx, data, col)
            return v if isinstance(v, str) else ''
        return ''

    def _maybe_add_cxr(self, tensors, chunk_idx, within_chunk_idx, data):
        if not self.use_img_model:
            return
        paths = None
        if 'xray_paths' in self.dataframe_cols:
            paths = self.read_col(chunk_idx, within_chunk_idx, data, 'xray_paths')
        if paths is not None and not isinstance(paths, str):
            images, times, present = self.img_processor.load_visit_images(paths)
        else:
            path = self._get_xray_path(chunk_idx, within_chunk_idx, data)
            image, present_flag = self.img_processor.load_image_with_presence(path)
            images = image.unsqueeze(0) if present_flag else image.new_zeros(0, *image.shape)
            times = torch.zeros(1 if present_flag else 0, dtype=torch.long)
            present = torch.tensor([present_flag], dtype=torch.bool)
        tensors['cxr_images'] = images
        tensors['cxr_time'] = times
        tensors['cxr_present'] = present

    def _to_int64(self, arr):
        """numpy array of any shape (possibly nested list from parquet) → int64 tensor."""
        return torch.as_tensor(np.asarray(arr, dtype=np.int64))

    def read_sample(self, chunk_idx: int, within_chunk_idx: int, data: dict):
        tensors = {
            'cat_feats': self._to_int64(self.read_col(
                chunk_idx, within_chunk_idx, data, 'tokenized_category_feats')),
            'float_feats': self._to_int64(self.read_col(
                chunk_idx, within_chunk_idx, data, 'tokenized_float_feats')),
            'valid_mask': torch.as_tensor(
                np.asarray(self.read_col(chunk_idx, within_chunk_idx, data, 'valid_mask'), dtype=bool)),
            'time_index': self._to_int64(self.read_col(
                chunk_idx, within_chunk_idx, data, 'time_index')),
            'cohort_id': torch.tensor(
                self._get_cohort_id(chunk_idx, within_chunk_idx, data), dtype=torch.long),
            # Default: EHR is always present (we always have some lab data per
            # patient in COMPASS). Modality-dropout in training_step or
            # inference-mode configs can override this per sample.
            'ehr_present': torch.tensor(True, dtype=torch.bool),
        }
        self._maybe_add_cxr(tensors, chunk_idx, within_chunk_idx, data)
        return tensors

    def read_sample_label_pretrain(self, chunk_idx: int, within_chunk_idx: int, data: dict):
        """Feature-level masking for pretraining.

        Vectorised: per timestep with ≥1 valid feature, ~``mask_ratio`` of those
        features are randomly selected; their input tokens are zeroed to -1
        (the "missing" sentinel) and the matching positions in the output
        tensors are filled with the reconstruction targets.
        """
        cat_tok = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'tokenized_category_feats'), dtype=np.int64)
        float_tok = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'tokenized_float_feats'), dtype=np.int64)
        valid_mask = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'valid_mask'), dtype=bool)
        orig_cat = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'category_feats'), dtype=np.int64)
        orig_float = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'float_feats'), dtype=np.float32)
        time_index = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'time_index'), dtype=np.int64)

        n_cat, L = cat_tok.shape
        n_float = float_tok.shape[0]

        # Per-(feature, timestep) "present" matrices.
        # Drop non-finite / absurd raw values (e.g. corrupted timestamps stored
        # as floats ~1e16+); they would explode MSE even after z-scoring.
        raw_ok = np.isfinite(orig_float) & (np.abs(orig_float) < 1e6)
        if self.log1p_float_idx:
            orig_float = orig_float.copy()
            for i in self.log1p_float_idx:
                vals = orig_float[i]
                ok = raw_ok[i] & (vals >= 0)
                orig_float[i] = np.where(ok, np.log1p(vals), orig_float[i])
        cat_present = (cat_tok != -1) & (cat_tok != 256) & valid_mask[None, :]
        float_present = raw_ok & valid_mask[None, :] & (float_tok != -1) & (float_tok != 256)

        # Stack cat- and float-feature presence into one (n_cat + n_float, L) grid
        # so we can sample a uniform fraction across modalities.
        present = np.concatenate([cat_present, float_present], axis=0)
        keep_prob = 1.0 - self.mask_ratio
        rand = np.random.random(present.shape)
        # `output` selects features to RECONSTRUCT (≈ mask_ratio of present ones).
        is_output = present & (rand >= keep_prob)
        # `input` retains the rest of the present features for the encoder.
        is_input = present & ~is_output

        # Guarantee ≥1 reconstructed feature per timestep that has any valid feature,
        # mirroring the original behaviour.
        has_present_t = present.any(axis=0)
        has_output_t = is_output.any(axis=0)
        force_t = np.where(has_present_t & ~has_output_t)[0]
        if force_t.size:
            for t in force_t:
                cand = np.where(present[:, t])[0]
                pick = np.random.choice(cand)
                is_output[pick, t] = True
                is_input[pick, t] = False

        # Visit-level masking: hide entire follow-ups so the temporal model
        # must interpolate the longitudinal course.
        hidden_visits = np.zeros(L, dtype=bool)
        visit_p = getattr(self, 'visit_mask_ratio', 0.0)
        if visit_p > 0:
            valid_t = np.where(valid_mask)[0]
            if valid_t.size >= 2:
                hide = valid_t[np.random.random(valid_t.size) < visit_p]
                if hide.size >= valid_t.size:
                    hide = hide[: valid_t.size - 1]
                if hide.size:
                    hidden_visits[hide] = True
                    is_output[:, hide] = present[:, hide]
                    is_input[:, hide] = False

        cat_in_mask, float_in_mask = is_input[:n_cat], is_input[n_cat:]
        cat_out_mask, float_out_mask = is_output[:n_cat], is_output[n_cat:]

        # Build inputs: blank out the to-be-reconstructed slots.
        cat_input = np.where(cat_out_mask, -1, cat_tok).astype(np.int64)
        float_input = np.where(float_out_mask, -1, float_tok).astype(np.int64)

        # Build targets.
        cat_target = np.where(cat_out_mask, orig_cat, 0).astype(np.int64)

        mean = self.mean_std[:, 0].reshape(-1, 1)
        std = self.mean_std[:, 1].reshape(-1, 1)
        # Avoid normalising garbage where the original value is missing.
        safe_float = np.where(raw_ok, orig_float, 0.0)
        float_normed = (safe_float - mean) / (std + 1e-10)
        # Clamp z-scores so a few remaining outliers cannot dominate the loss.
        float_normed = np.clip(float_normed, -10.0, 10.0)
        float_target = np.where(float_out_mask, float_normed, 0.0).astype(np.float32)

        sample = {
            'cat_feats': torch.from_numpy(cat_input),
            'cat_valid_mask': torch.from_numpy(cat_in_mask),
            'float_feats': torch.from_numpy(float_input),
            'float_valid_mask': torch.from_numpy(float_in_mask),
            'cohort_id': torch.tensor(
                self._get_cohort_id(chunk_idx, within_chunk_idx, data), dtype=torch.long),
            'ehr_present': torch.tensor(True, dtype=torch.bool),
            'time_index': torch.from_numpy(np.clip(time_index, 0, None)),
        }
        self._maybe_add_cxr(sample, chunk_idx, within_chunk_idx, data)
        if hidden_visits.any() and 'cxr_present' in sample:
            cp = sample['cxr_present']
            if cp.numel() == L:
                cp = cp.clone()
                cp[torch.from_numpy(hidden_visits)] = False
                sample['cxr_present'] = cp

        label = {
            'cat_feats': torch.from_numpy(cat_target),
            'cat_valid_mask': torch.from_numpy(cat_out_mask),
            'float_feats': torch.from_numpy(float_target),
            'float_valid_mask': torch.from_numpy(float_out_mask),
        }
        return sample, label

    def read_label(self, chunk_idx: int, within_chunk_idx: int, data: dict):
        """Build the per-patient label dict for finetuning.

        Always returns dense ``values``/``masks`` tensors (zero-row when a
        modality has no labels), so downstream code can index them
        unconditionally.
        """
        if self.config.get('mode') == 'pretrain':
            return None

        time_index = np.asarray(self.read_col(
            chunk_idx, within_chunk_idx, data, 'time_index'), dtype=np.int64)
        seq_len = time_index.shape[0]

        def _stack(value_cols, norm_info=None, log1p_idx=None, winsor_q=None):
            """Concatenate every per-task row into flat lists; optionally normalise."""
            values, masks = [], []
            log1p_idx = set(log1p_idx or [])
            for col in value_cols:
                v = np.asarray(self.read_col(chunk_idx, within_chunk_idx, data, col))
                if v.ndim == 1:
                    v = v[None, :]
                v = v.astype(np.float32)
                for row in v:
                    nan = np.isnan(row) | (row == -1)
                    valid = ~nan
                    out = row.copy()
                    i = len(values)
                    if i in log1p_idx:
                        ok = valid & (out >= 0)
                        out = np.where(ok, np.log1p(out), out)
                    if winsor_q is not None and i in log1p_idx and valid.any():
                        lo, hi = winsor_q.get(i, (None, None))
                        if lo is not None and hi is not None:
                            out = np.where(valid, np.clip(out, lo, hi), out)
                    if norm_info is not None and i < len(norm_info):
                        mean, std = norm_info[i]
                        out = np.where(valid, (out - mean) / (std + 1e-10), out)
                    values.append(np.where(nan, -1, out))
                    masks.append(valid)
            return values, masks

        cls_values, cls_masks = _stack(self.config['cls_label_cols'])
        reg_log1p_names = set(self.config.get('reg_log1p_cols') or [])
        reg_names = list(self.config.get('reg_label_names') or [])
        # Names are filled in _setup_config as f'{col}_{name}'; also accept bare names.
        log1p_idx = []
        for i, full in enumerate(reg_names):
            bare = full.split('_', 1)[-1] if '_' in full else full
            # reg_cols are like c_reg_labels_UACR → after first split still has prefix
            bare2 = full.rsplit('_', 1)[-1]
            if full in reg_log1p_names or bare in reg_log1p_names or bare2 in reg_log1p_names:
                log1p_idx.append(i)
        # Prefer precomputed winsor bounds on the log1p scale when provided.
        winsor_q = None
        preset = self.config.get('reg_log1p_winsor') or {}
        if preset and log1p_idx:
            winsor_q = {}
            for i in log1p_idx:
                full = reg_names[i]
                bare2 = full.rsplit('_', 1)[-1]
                key = bare2 if bare2 in preset else (full if full in preset else None)
                if key is not None:
                    lo, hi = preset[key]
                    winsor_q[i] = (float(lo), float(hi))
        # Override z-score stats for log1p targets when provided.
        reg_info = self.config.get('reg_label_info')
        if reg_info is not None and self.config.get('reg_log1p_mean_std'):
            reg_info = [list(x) for x in reg_info]
            stats = self.config['reg_log1p_mean_std']
            for i in log1p_idx:
                bare2 = reg_names[i].rsplit('_', 1)[-1]
                if bare2 in stats:
                    reg_info[i] = list(stats[bare2])
        reg_values, reg_masks = _stack(
            self.config.get('reg_label_cols', []),
            norm_info=reg_info,
            log1p_idx=log1p_idx,
            winsor_q=winsor_q,
        )

        def _to_tensors(values, masks, *, long):
            if values:
                v = np.stack(values, axis=0)
                m = np.stack(masks, axis=0)
            else:
                v = np.zeros((0, seq_len), dtype=np.float32 if not long else np.int64)
                m = np.zeros((0, seq_len), dtype=bool)
            if long:
                v = v.astype(np.int64, copy=False)
                v[v == -1] = 0
                return torch.from_numpy(v), torch.from_numpy(m)
            return torch.from_numpy(v.astype(np.float32, copy=False)), torch.from_numpy(m)

        cls_v, cls_m = _to_tensors(cls_values, cls_masks, long=True)
        reg_v, reg_m = _to_tensors(reg_values, reg_masks, long=False)

        out = {
            'cls': {'values': cls_v, 'masks': cls_m},
            'reg': {'values': reg_v, 'masks': reg_m},
            'time_index': torch.from_numpy(time_index.copy()),
        }
        if 'tx_base_raw' in self.dataframe_cols:
            base = np.asarray(
                self.read_col(chunk_idx, within_chunk_idx, data, 'tx_base_raw'),
                dtype=np.float32,
            ).reshape(-1).copy()
            out['tx_base_raw'] = torch.from_numpy(base)
        return out

    def __len__(self):
        return self.total_length

    def __getitem__(self, idx):
        chunk_idx = np.searchsorted(self.cumulative_lengths, idx, side='right')
        within_chunk_idx = (
            idx - self.cumulative_lengths[chunk_idx - 1] if chunk_idx > 0 else idx
        )
        # Compute the per-sample runtime slice from the raw valid_mask BEFORE
        # any read_col call applies it (otherwise we'd recurse infinitely).
        raw_valid = self._preloaded[chunk_idx]['valid_mask'][within_chunk_idx]
        self._current_slice = self._runtime_slice(raw_valid)
        data = None  # diskcache slot vestige — see read_col docstring.

        if self.config.get('mode') == 'pretrain':
            sample, label = self.read_sample_label_pretrain(chunk_idx, within_chunk_idx, data)
            return {
                'pid': self.read_col(chunk_idx, within_chunk_idx, data, self.pid_col),
                'data': sample,
                'label': label,
            }
        return {
            'pid': self.read_col(chunk_idx, within_chunk_idx, data, self.pid_col),
            'data': self.read_sample(chunk_idx, within_chunk_idx, data),
            'label': self.read_label(chunk_idx, within_chunk_idx, data),
        }

def collate_onco(batch):
    """Stack tabular fields and pack only the visits that have a chest film."""
    packed = []
    times = []
    present = []
    for sample in batch:
        data = sample.get('data') or {}
        packed.append(data.pop('cxr_images', None))
        times.append(data.pop('cxr_time', None))
        present.append(data.pop('cxr_present', None))
    out = default_collate(batch)
    images = []
    slots = []
    img_size = None
    for i, (img, tm) in enumerate(zip(packed, times)):
        if img is None or tm is None or getattr(img, 'ndim', 0) < 4 or img.shape[0] == 0:
            if img is not None and getattr(img, 'ndim', 0) >= 3 and img.shape[-1] > 0:
                img_size = img.shape[-1]
            continue
        img_size = img.shape[-1]
        images.append(img)
        batch_ix = torch.full((tm.shape[0],), i, dtype=torch.long)
        slots.append(torch.stack([batch_ix, tm.long()], dim=1))
    if images:
        out['data']['cxr_images'] = torch.cat(images, dim=0)
        out['data']['cxr_slots'] = torch.cat(slots, dim=0)
    else:
        side = img_size or 518
        out['data']['cxr_images'] = torch.zeros(0, 3, side, side)
        out['data']['cxr_slots'] = torch.zeros(0, 2, dtype=torch.long)
    if present and present[0] is not None:
        out['data']['cxr_present'] = torch.stack(present, dim=0)
    return out


class OncoDataModule(pl.LightningDataModule):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.df_paths = config.get('df_paths', [])
        self.dataset_col = config.get('dataset_col', None)
        self.batch_size = config.get('batch_size', None)
        self.train_folds = config.get('train_folds', None)
        self.valid_folds = config.get('valid_folds', None)
        self.test_folds = config.get('test_folds', None)

    def setup(self, stage=None):
        if not isinstance(self.df_paths, list):
            self.df_paths = [self.df_paths]
        if isinstance(self.df_paths[0], pd.DataFrame):
            self._setup_from_dataframe()
        else:
            self._setup_from_parquet()

    def _setup_from_dataframe(self):
        df = pd.concat(sorted(self.df_paths), axis=0, ignore_index=True)
        df = optimize_dtypes(df)
        
        
        df_train = df[df[self.dataset_col].isin(self.train_folds)].reset_index(drop=True)
        df_valid = df[df[self.dataset_col].isin(self.valid_folds)].reset_index(drop=True)
        df_test = df[df[self.dataset_col].isin(self.test_folds)].reset_index(drop=True)
        
        
        self.config['df_paths'] = self.df_paths  
        
        
        self.ds_train = ChunkedOncoDataset([df_train], 'train', self.config)
        self.ds_valid = ChunkedOncoDataset([df_valid], 'valid', self.config)
        self.ds_test = ChunkedOncoDataset([df_test], 'test', self.config)

    def _setup_from_parquet(self):
        self.config['df_paths'] = self.df_paths
        pid_col = self.config.get('pid_col', 'patient_id')

        # Fast path: mmap pre-materialized arrays so DDP ranks share one copy.
        # Finetune cache omits raw float/category; pretrain cache includes them.
        cache_root = Path(self.df_paths[0])
        mode = self.config.get('mode', 'finetune')
        if array_cache_ready(cache_root, mode=mode):
            import json
            summary_path = cache_root / 'summary.json'
            disease_names = []
            if summary_path.exists():
                disease_names = json.loads(summary_path.read_text()).get('disease_names', [])
            splits = {}
            for split in ('train', 'valid', 'test'):
                df, pre = load_array_cache(
                    array_cache_dir(cache_root, split), pid_col, disease_names)
                splits[split] = ChunkedOncoDataset(
                    [df], split if split != 'valid' else 'valid', self.config,
                    preload_arrays=[pre],
                )
            self.ds_train = splits['train']
            self.ds_valid = splits['valid']
            self.ds_test = splits['test']
            print(
                f'[array_cache/{mode}] mmap train={len(self.ds_train)} '
                f'val={len(self.ds_valid)} test={len(self.ds_test)}',
                flush=True,
            )
            return

        dfs = []
        for path in sorted(self.df_paths):
            metadata_path = Path(path) / 'metadata.parquet'
            df = load_parquet(metadata_path)
            dfs.append(df)

        merged_df = pd.concat(dfs, axis=0, ignore_index=True)
        merged_df = optimize_dtypes(merged_df)

        df_train = merged_df[merged_df[self.dataset_col].isin(self.train_folds)].reset_index(drop=True)
        df_valid = merged_df[merged_df[self.dataset_col].isin(self.valid_folds)].reset_index(drop=True)
        df_test = merged_df[merged_df[self.dataset_col].isin(self.test_folds)].reset_index(drop=True)

        self.ds_train = ChunkedOncoDataset([df_train], 'train', self.config)
        self.ds_valid = ChunkedOncoDataset([df_valid], 'valid', self.config)

        if self.config.get('test_df', '') != '':
            df_test = pd.read_csv(self.config['test_df'])
            df_test = optimize_dtypes(df_test)
            self.ds_test = ChunkedOncoDataset([df_test], 'test', self.config)
        else:
            self.ds_test = ChunkedOncoDataset([df_test], 'test', self.config)

    def _make_loader(self, dataset, shuffle=False, sampler=None):
        num_workers = 0 if sys.platform == 'win32' else int(self.config.get('num_workers', 4))
        prefetch = int(self.config.get('prefetch_factor', 2))
        kwargs = dict(
            batch_size=self.batch_size,
            num_workers=num_workers,
            pin_memory=True,
        )
        if sampler is not None:
            kwargs['sampler'] = sampler
            kwargs['shuffle'] = False
        else:
            kwargs['shuffle'] = shuffle
        if num_workers > 0:
            kwargs.update(
                persistent_workers=True,
                prefetch_factor=max(2, prefetch),
                multiprocessing_context=_MP_CONTEXT,
            )
        if self.config.get('use_img_model', False):
            kwargs['collate_fn'] = collate_onco
        return DataLoader(dataset, **kwargs)

    def _patient_head_positives(self, dataset, label_col: str) -> np.ndarray:
        """(n_patients, n_heads) bool: any positive visit for each disease head.

        Array-cache splits keep labels in the mmap, not in the pandas frame.
        """
        pres = getattr(dataset, 'preload_arrays', None) or []
        parts = []
        for ci, chunk in enumerate(dataset.data_chunks):
            pre = pres[ci] if ci < len(pres) else None
            if pre is not None and label_col in pre:
                lab = np.asarray(pre[label_col])
                if lab.ndim == 1:
                    parts.append((lab == 1)[:, None])
                elif lab.ndim == 2:
                    parts.append((lab == 1).any(axis=-1)[:, None])
                else:
                    parts.append((lab == 1).any(axis=-1))
                continue
            rows = []
            for i in range(len(chunk)):
                lab = np.asarray(chunk.iloc[i][label_col])
                if lab.ndim == 1:
                    rows.append(np.array([(lab == 1).any()]))
                else:
                    rows.append((lab == 1).any(axis=1))
            if rows:
                parts.append(np.stack([np.atleast_1d(r) for r in rows], axis=0))
        if not parts:
            return np.zeros((0, 1), dtype=bool)
        return np.concatenate(parts, axis=0)

    def _positive_patient_weights(self, dataset):
        """Up-weight patients with >=1 positive binary label (helps AP)."""
        label_cols = self.config.get('cls_label_cols', [])
        boost = float(self.config.get('pos_sampler_boost', 5.0))
        n = len(dataset)
        weights = np.ones(n, dtype=np.float64)
        if not label_cols or n == 0:
            return weights
        head_pos = self._patient_head_positives(dataset, label_cols[0])
        if len(head_pos) != n:
            raise RuntimeError(f'label rows {len(head_pos)} != dataset {n}')
        weights[head_pos.any(axis=1)] = boost
        return weights

    def _rebalance_patient_weights(self, dataset):
        """Cap rare-class oversampling and down-weight negatives.

        Classes with prevalence below ``sampler_rare_prevalence`` (default 1%)
        are boosted by at most ``sampler_max_boost`` (default 3). More common
        positives (e.g. CKD) stay at weight 1. Negatives use
        ``sampler_neg_weight`` (default 0.5). The cap is intentional: heads
        with only a few hundred training patients overfit if repeated tens of
        times per epoch.
        """
        label_cols = self.config.get('cls_label_cols', [])
        max_boost = float(self.config.get('sampler_max_boost', 3.0))
        neg_w = float(self.config.get('sampler_neg_weight', 0.5))
        rare_prev = float(self.config.get('sampler_rare_prevalence', 0.01))
        n = len(dataset)
        weights = np.full(n, neg_w, dtype=np.float64)
        if not label_cols or n == 0:
            return weights
        head_pos = self._patient_head_positives(dataset, label_cols[0])
        if len(head_pos) != n:
            raise RuntimeError(f'label rows {len(head_pos)} != dataset {n}')
        if head_pos.ndim == 1:
            head_pos = head_pos[:, None]
        n_heads = head_pos.shape[1]
        prev = head_pos.mean(axis=0)
        head_boost = np.ones(n_heads, dtype=np.float64)
        for h in range(n_heads):
            if prev[h] <= 0 or prev[h] >= rare_prev:
                continue
            boost = float(np.sqrt(rare_prev / max(float(prev[h]), 1e-8)))
            head_boost[h] = min(max_boost, max(1.0, boost))
        any_pos = head_pos.any(axis=1)
        pos_w = np.where(head_pos, head_boost[None, :], 0.0).max(axis=1)
        weights = np.where(any_pos, pos_w, neg_w).astype(np.float64)
        print(
            f'[sampler] n={n} rare_boosts='
            + ','.join(f'{b:.2f}' for b in head_boost)
            + f' neg={neg_w}',
            flush=True,
        )
        return weights

    def _patient_has_reg_label(self, dataset) -> np.ndarray:
        """True if the patient has any non-missing regression target."""
        reg_cols = self.config.get('reg_label_cols') or []
        n = len(dataset)
        if not reg_cols or n == 0:
            return np.zeros(n, dtype=bool)
        col = reg_cols[0]
        pres = getattr(dataset, 'preload_arrays', None) or []
        flags = []
        for ci, chunk in enumerate(dataset.data_chunks):
            pre = pres[ci] if ci < len(pres) else None
            if pre is not None and col in pre:
                lab = np.asarray(pre[col])
                ok = np.isfinite(lab) & (lab != -1)
                if ok.ndim == 1:
                    flags.append(ok)
                else:
                    flags.append(ok.reshape(ok.shape[0], -1).any(axis=1))
                continue
            rows = []
            for i in range(len(chunk)):
                lab = np.asarray(chunk.iloc[i][col], dtype=np.float64)
                ok = np.isfinite(lab) & (lab != -1)
                rows.append(bool(np.any(ok)))
            flags.append(np.asarray(rows, dtype=bool))
        out = np.concatenate(flags, axis=0) if flags else np.zeros(n, dtype=bool)
        if len(out) != n:
            raise RuntimeError(f'reg flags {len(out)} != dataset {n}')
        return out

    def train_dataloader(self):
        sampler = None
        if self.config.get('use_pos_sampler', False):
            from torch.utils.data import WeightedRandomSampler
            mode = str(self.config.get('sampler_mode', 'capped'))
            if mode == 'hybrid_pos_and_reg':
                w = self._rebalance_patient_weights(self.ds_train)
                reg_boost = float(self.config.get('reg_sampler_boost', 3.0))
                has_reg = self._patient_has_reg_label(self.ds_train)
                w = np.maximum(w, np.where(has_reg, reg_boost, 0.0))
                print(
                    f'[sampler] hybrid pos+reg: n_reg={int(has_reg.sum())} '
                    f'reg_boost={reg_boost}',
                    flush=True,
                )
            elif mode == 'capped':
                w = self._rebalance_patient_weights(self.ds_train)
            else:
                w = self._positive_patient_weights(self.ds_train)
            sampler = WeightedRandomSampler(
                weights=torch.as_tensor(w, dtype=torch.double),
                num_samples=len(w),
                replacement=True,
            )
        return self._make_loader(self.ds_train, shuffle=True, sampler=sampler)

    def val_dataloader(self):
        return self._make_loader(self.ds_valid, shuffle=False)

    def test_dataloader(self):
        return self._make_loader(self.ds_test, shuffle=False)

    def teardown(self, stage=None):
        gc.collect()
