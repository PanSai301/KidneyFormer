"""Kidneyformer pretraining module with feature-level masking and multimodal support."""

import gc
import math
from pathlib import Path
from collections import defaultdict

import numpy as np
import torch
import torch.nn.functional as F
import torch.distributed as dist
import pandas as pd
import pytorch_lightning as pl
import torchmetrics.functional as MF
from torch.optim import AdamW
from torchmetrics.utilities.data import dim_zero_cat
from sklearn.metrics import precision_recall_curve
from tqdm import tqdm

from kidneyformer_code.kidneyformer import Oncoformer
from kidneyformer_code.kidneyformer_ddp import all_gather
from kidneyformer_code.kidneyformer_scheduler import CosineAnnealingWarmupRestarts


class OncoModule(pl.LightningModule):
    """Lightning module for Kidneyformer self-supervised pretraining.

    Objective: mask 50 % of valid clinical features per timestamp and
    reconstruct them in BOTH the current and (with ``predict_next_visit``)
    the subsequent visit, matching the MLM definition in Methods.

    Auxiliary adversarial losses (gated by config) train the encoder to be
    invariant to (a) the patient's cohort label and (b) per-feature
    missingness patterns, via gradient reversal.
    """

    def __init__(self, config):
        super().__init__()

        self.config = config
        self.config['mode'] = 'pretrain'

        self.data_type = config.get('data_type', '')
        self.momentum = config.get('momentum', 0.9)
        self.wd = config.get('wd', 1e-6)
        self.lr = config.get('lr', 1e-3)
        self.n_nodes = config.get('n_nodes', 1)
        self.n_gpus = config.get('n_gpus', 1)
        if isinstance(self.n_gpus, list):
            self.n_gpus = len(self.n_gpus)
        self.n_epoch = config.get('n_epoch', None)

        if 'feat_info' in config:
            self.cls_label_names = sorted(config['feat_info']['category_cols'])
            self.reg_label_names = sorted(config['feat_info']['float_cols'].keys())
        else:
            self.cls_label_names = config.get('cls_label_names', [])
            self.reg_label_names = config.get('reg_label_names', [])

        self.config['cls_label_names'] = self.cls_label_names
        self.config['reg_label_names'] = self.reg_label_names

        self.model = Oncoformer(config)

        self.output_dir = config.get('output_dir', None)
        if self.output_dir is not None:
            self.output_dir = Path(self.output_dir) / 'pred'
            self.output_dir.mkdir(parents=True, exist_ok=True)
        self.pred_folder = config.get('pred_folder', 'pred')

        # Adversarial-loss configuration
        self.use_cohort_adv = config.get('use_cohort_adv', False)
        self.use_missingness_adv = config.get('use_missingness_adv', False)
        self.cohort_adv_weight = config.get('cohort_adv_weight', 0.1)
        self.missingness_adv_weight = config.get('missingness_adv_weight', 0.1)
        self.grl_lambda_max = config.get('grl_lambda_max', 1.0)

        # Optional next-visit MLM term
        self.predict_next_visit = config.get('predict_next_visit', True)
        self.next_visit_weight = config.get('next_visit_weight', 1.0)

    # ------------------------------------------------------------------
    # Optimizer & scheduler
    # ------------------------------------------------------------------

    def configure_optimizers(self):
        optimizer = AdamW(
            params=self.model.parameters(),
            lr=self.lr,
            weight_decay=self.wd,
            betas=(
                float(self.config.get('beta1', 0.9)),
                float(self.config.get('beta2', 0.999)),
            ),
        )
        warmup = int(self.config.get('warmup_epochs', 0))
        if warmup <= 0:
            warmup = max(1, int(round(0.1 * self.n_epoch)))
        warmup = min(warmup, max(1, self.n_epoch - 1))
        scheduler = CosineAnnealingWarmupRestarts(
            optimizer,
            first_cycle_steps=self.n_epoch,
            max_lr=self.lr,
            min_lr=float(self.config.get('min_lr', 1e-6)),
            warmup_steps=warmup,
        )
        return [optimizer], [scheduler]

    def lr_scheduler_step(self, scheduler, optimizer_idx):
        scheduler.step()

    def on_train_start(self):
        if not self.loggers:
            return
        # GPT2Config is not OmegaConf-safe; log a JSON-serializable subset.
        safe = {}
        for k, v in self.config.items():
            if k in {'transformer', 'feat_info', 'mean_std'}:
                continue
            if isinstance(v, (str, int, float, bool, list, dict, type(None))):
                safe[k] = v
        try:
            self.loggers[0].log_hyperparams(safe)
        except Exception:
            pass

    def on_train_epoch_start(self):
        # Standard DANN sigmoid schedule: λ ramps 0 → λ_max as training progresses.
        if self.n_epoch and self.n_epoch > 0:
            p = self.current_epoch / float(self.n_epoch)
        else:
            p = 0.0
        grl = 2.0 / (1.0 + math.exp(-10.0 * p)) - 1.0
        self.model.set_grl_lambda(grl * self.grl_lambda_max)
        self.log("grl_lambda", float(self.model.grl_lambda),
                 prog_bar=False, rank_zero_only=True)
        self.log("kl_beta", float(self._kl_beta()),
                 prog_bar=False, rank_zero_only=True)

        # Health metric for the post-DINOv2 projection layer (the only image-
        # side parameters that train when freeze_cxr_backbone=true). A frozen
        # backbone with a healthy projection should show:
        #   - cxr_proj_weight_norm growing from init across early epochs and
        #     stabilising;
        #   - non-zero gradient norm on the projection (logged each step).
        # A flat-zero weight norm or zero grad means the path isn't training.
        enc = self.model.multimodal_encoder
        proj = getattr(enc, 'cxr_projection', None)
        if proj is not None:
            self.log("cxr_proj_weight_norm",
                     proj.weight.detach().float().norm().item(),
                     prog_bar=False, rank_zero_only=True)

    def get_progress_bar_dict(self):
        tqdm_dict = super().get_progress_bar_dict()
        tqdm_dict.pop('v_num', None)
        return tqdm_dict

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_multimodal(data):
        return (
            data['cat_feats'],
            data['float_feats'],
            data['cat_valid_mask'],
            data['float_valid_mask'],
            data.get('cxr_images', None),
            data.get('cxr_present', None),
            data.get('cohort_id', None),
            data.get('ehr_present', None),
            data.get('cxr_slots', None),
        )

    @staticmethod
    def _batch_time_index(data, cat_feats):
        ti = data.get('time_index')
        if ti is None:
            L = cat_feats.shape[-1]
            return torch.arange(L, device=cat_feats.device).unsqueeze(0).expand(cat_feats.shape[0], -1)
        return ti.to(device=cat_feats.device).clamp(min=0)

    def _apply_modality_dropout(self, cxr_present, ehr_present):
        """Randomly drop one modality per sample during training.

        ``cxr_present`` may be per-visit ``(B, L)`` while ``ehr_present`` is
        per-sample ``(B,)``; broadcast EHR onto the visit axis when needed.
        """
        if not self.training:
            return cxr_present, ehr_present
        p_drop_cxr = self.config.get('p_drop_cxr', 0.25)
        p_drop_ehr = self.config.get('p_drop_ehr', 0.25)
        if cxr_present is None or ehr_present is None:
            return cxr_present, ehr_present
        if cxr_present.shape != ehr_present.shape:
            ehr_b = ehr_present.view(ehr_present.shape[0], *([1] * (cxr_present.dim() - 1)))
            both = cxr_present & ehr_b
        else:
            both = cxr_present & ehr_present
        if not both.any():
            return cxr_present, ehr_present
        device = cxr_present.device
        rand = torch.rand(cxr_present.shape, device=device)
        drop_cxr = both & (rand < p_drop_cxr)
        if cxr_present.shape == ehr_present.shape:
            drop_ehr = both & (rand >= p_drop_cxr) & (rand < p_drop_cxr + p_drop_ehr)
            ehr_present = ehr_present & ~drop_ehr
        return cxr_present & ~drop_cxr, ehr_present

    def _kl_beta(self):
        """β-VAE coefficient with linear annealing over the first 10% of epochs."""
        target = float(self.config.get('vae_kl_beta', self.config.get('vae_loss_weight', 1e-3)))
        frac = float(self.config.get('kl_anneal_frac', 0.1))
        n_epoch = max(int(self.n_epoch or 1), 1)
        anneal_epochs = max(1, int(round(frac * n_epoch)))
        p = min(1.0, (self.current_epoch + 1) / float(anneal_epochs))
        return p * target

    def _compute_vae_loss(self, vae_losses, prefix='train'):
        vae_loss_total = torch.tensor(0.0, device=self.device)
        vae_weight = self._kl_beta()

        if 'labtest_kl' in vae_losses:
            vae_loss_total = vae_loss_total + vae_losses['labtest_kl'] * vae_weight
            self.log(f"{prefix}_labtest_kl", vae_losses['labtest_kl'],
                     prog_bar=False, rank_zero_only=True, on_epoch=True)
        if 'cxr_kl' in vae_losses:
            vae_loss_total = vae_loss_total + vae_losses['cxr_kl'] * vae_weight
            self.log(f"{prefix}_cxr_kl", vae_losses['cxr_kl'],
                     prog_bar=False, rank_zero_only=True, on_epoch=True)
        if 'symmetric_kl' in vae_losses:
            sym_scale = float(self.config.get('symmetric_kl_weight', 1.0))
            vae_loss_total = vae_loss_total + vae_losses['symmetric_kl'] * vae_weight * sym_scale
            self.log(f"{prefix}_symmetric_kl", vae_losses['symmetric_kl'],
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

        return vae_loss_total

    def _compute_adv_losses(self, aux, cat_feats, float_feats, cohort_id,
                            valid_mask, prefix='train'):
        cohort_loss = torch.tensor(0.0, device=self.device)
        miss_loss = torch.tensor(0.0, device=self.device)

        if self.use_cohort_adv and aux.get('cohort_logits') is not None and cohort_id is not None:
            cohort_loss = F.cross_entropy(aux['cohort_logits'], cohort_id)
            self.log(f"{prefix}_cohort_adv_loss", cohort_loss,
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

        if self.use_missingness_adv and aux.get('missingness_logits') is not None:
            # Targets: was the input feature value missing (== -1)?
            miss_target = torch.cat(
                [(cat_feats == -1), (float_feats == -1)], dim=1,
            ).permute(0, 2, 1).contiguous().to(aux['missingness_logits'].dtype)
            miss_logits = aux['missingness_logits']
            per_elem = F.binary_cross_entropy_with_logits(
                miss_logits, miss_target, reduction='none',
            )  # (B, L, n_features_total)
            elem_mask = valid_mask.unsqueeze(-1).expand_as(per_elem).float()
            miss_loss = (per_elem * elem_mask).sum() / elem_mask.sum().clamp(min=1)
            self.log(f"{prefix}_missingness_adv_loss", miss_loss,
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

        return cohort_loss * self.cohort_adv_weight + miss_loss * self.missingness_adv_weight

    @staticmethod
    def _shift_left(t, fill):
        """Drop position 0, slide the rest left, pad final position with `fill`."""
        B = t.shape[0]
        head = t.shape[1:-1]
        L = t.shape[-1]
        tail_shape = (B, *head, 1)
        tail = torch.full(tail_shape, fill, dtype=t.dtype, device=t.device)
        return torch.cat([t[..., 1:], tail], dim=-1)

    def _reconstruction_loss(self, cls_preds, reg_preds,
                             cls_label, cls_mask,
                             reg_label, reg_mask):
        reg_loss = torch.tensor(0.0, device=self.device)
        n_reg_tasks = 0
        if reg_preds and reg_label.shape[1] > 0:
            for i in range(min(len(reg_preds), reg_label.shape[1])):
                y = reg_preds[i].reshape(-1)
                t = reg_label[:, i, :].reshape(-1)
                m = reg_mask[:, i, :].reshape(-1).float()
                l = F.mse_loss(y, t, reduction='none')
                reg_loss = reg_loss + (l * m).sum() / m.sum().clamp(min=1)
                n_reg_tasks += 1
        if n_reg_tasks > 0:
            reg_loss = reg_loss / n_reg_tasks

        cls_loss = torch.tensor(0.0, device=self.device)
        n_cls_tasks = 0
        if cls_preds and cls_label.shape[1] > 0:
            for i in range(min(len(cls_preds), cls_label.shape[1])):
                y = cls_preds[i].reshape(-1, 2)
                t = cls_label[:, i, :].reshape(-1)
                m = cls_mask[:, i, :].reshape(-1).float()
                l = F.cross_entropy(y, t, reduction='none')
                cls_loss = cls_loss + (l * m).sum() / m.sum().clamp(min=1)
                n_cls_tasks += 1
        if n_cls_tasks > 0:
            cls_loss = cls_loss / n_cls_tasks

        return cls_loss, reg_loss

    def _compute_pretrain_loss(self, pretrain_outputs,
                               cls_label, cls_mask, reg_label, reg_mask):
        """Current-visit + (optional) next-visit reconstruction loss."""
        cls_loss, reg_loss = self._reconstruction_loss(
            pretrain_outputs['cls_current'], pretrain_outputs['reg_current'],
            cls_label, cls_mask, reg_label, reg_mask,
        )

        next_loss = torch.tensor(0.0, device=self.device)
        if self.predict_next_visit and pretrain_outputs['cls_next']:
            next_cls_label = self._shift_left(cls_label, fill=0)
            next_cls_mask = self._shift_left(cls_mask, fill=False)
            next_reg_label = self._shift_left(reg_label, fill=0.0)
            next_reg_mask = self._shift_left(reg_mask, fill=False)

            cls_loss_n, reg_loss_n = self._reconstruction_loss(
                pretrain_outputs['cls_next'], pretrain_outputs['reg_next'],
                next_cls_label, next_cls_mask, next_reg_label, next_reg_mask,
            )
            next_loss = (cls_loss_n + reg_loss_n) * self.next_visit_weight
            cls_loss = cls_loss + cls_loss_n * self.next_visit_weight
            reg_loss = reg_loss + reg_loss_n * self.next_visit_weight

        return cls_loss, reg_loss, next_loss

    def _combine_pretrain_losses(self, cls_loss, reg_loss, vae_loss, adv_loss):
        gamma = float(self.config.get('recon_cat_weight', 1.0))
        recon_num_w = float(self.config.get('recon_num_weight', 1.0))
        recon_num = recon_num_w * reg_loss
        recon_cat = gamma * cls_loss
        total = recon_num + recon_cat + vae_loss + adv_loss
        return total, recon_num, recon_cat

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def training_step(self, batch, batch_idx):
        data = batch['data']
        label = batch['label']

        (cat_feats, float_feats, cat_valid_mask, float_valid_mask,
         cxr_images, cxr_present, cohort_id, ehr_present, cxr_slots) = self._extract_multimodal(data)
        cxr_present, ehr_present = self._apply_modality_dropout(cxr_present, ehr_present)

        reg_label = label['float_feats']
        reg_mask = label['float_valid_mask']
        cls_label = label['cat_feats']
        cls_mask = label['cat_valid_mask']

        valid_mask = cat_valid_mask.any(dim=1) | float_valid_mask.any(dim=1)
        time_index = self._batch_time_index(data, cat_feats)

        pretrain_outputs, aux = self.model(
            cat_feats, float_feats, valid_mask, time_index,
            cxr_images=cxr_images, cxr_present=cxr_present, ehr_present=ehr_present,
            cxr_slots=cxr_slots,
        )

        cls_loss, reg_loss, next_loss = self._compute_pretrain_loss(
            pretrain_outputs, cls_label, cls_mask, reg_label, reg_mask,
        )
        vae_loss = self._compute_vae_loss(aux['vae'], prefix='train')
        adv_loss = self._compute_adv_losses(
            aux, cat_feats, float_feats, cohort_id, valid_mask, prefix='train',
        )

        loss, recon_num, recon_cat = self._combine_pretrain_losses(
            cls_loss, reg_loss, vae_loss, adv_loss,
        )
        self.log("train_loss", loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_cls_loss", cls_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_reg_loss", reg_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_next_loss", next_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_recon_num", recon_num, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_recon_cat", recon_cat, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_vae_loss", vae_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        self.log("train_adv_loss", adv_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)

        # Per-step contribution norm of the (post-DINOv2) projection: average
        # L2 magnitude of cxr_projection(cxr_features) gated by cxr_present.
        # Non-zero and stable across epochs = the projection actually carries
        # image signal into the temporal transformer.
        contrib = aux.get('vae', {}).get('cxr_contribution_norm')
        if contrib is not None and cxr_present is not None and cxr_present.any():
            self.log("train_cxr_contribution_norm", contrib,
                     prog_bar=False, rank_zero_only=True, on_epoch=True)
        return loss

    def on_after_backward(self):
        # Grad-norm health for the trainable image-side path. Logged per step,
        # rank-zero only, low overhead (one .norm() per step).
        proj = getattr(self.model.multimodal_encoder, 'cxr_projection', None)
        if proj is not None and proj.weight.grad is not None:
            self.log("train_cxr_proj_grad_norm",
                     proj.weight.grad.detach().float().norm().item(),
                     prog_bar=False, rank_zero_only=True, on_epoch=True)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def on_validation_epoch_start(self) -> None:
        # Per-mode prediction buckets — keys like "cls_0", "ehr_only_cls_0",
        # "img_only_reg_3", etc. The "" prefix is the default fused mode and
        # keeps the existing val_loss / val_mauc / val_mpcc names so existing
        # checkpoint callbacks keep working unchanged.
        self.preds = defaultdict(list)
        self.targets = defaultdict(list)

    def _ablation_modes_this_epoch(self):
        """Return the list of (prefix, cxr_override, ehr_override, subset_cxr)
        tuples to run this epoch. ``subset_cxr`` restricts the metric to the
        subset of samples whose original `cxr_present` is True (used for the
        image-only mode so we don't dilute the metric with patients who have
        no image to look at).

        Ablation eval is OFF by default. Enable by setting
        ``ablation_every_n_epochs`` in the config:
          - ``0`` (or missing) → fused only, no ablation passes (cheapest).
          - ``1``              → run all three modes every val epoch.
          - ``N>1``            → run all three modes once every N epochs.
        """
        modes = [('', None, None, False)]  # always: fused / default
        every = int(self.config.get('ablation_every_n_epochs', 0))
        if every <= 0:
            return modes
        run_ablation = (every == 1) or ((self.current_epoch + 1) % every == 0)
        if run_ablation:
            modes.append(('ehr_only_', 'off', None, False))
            modes.append(('img_only_', None, 'off', True))
        return modes

    def validation_step(self, batch, batch_idx):
        fused_loss = None
        for prefix, cxr_override, ehr_override, subset_cxr in self._ablation_modes_this_epoch():
            loss = self._run_val_pass(
                batch, prefix=prefix,
                cxr_override=cxr_override, ehr_override=ehr_override,
                subset_cxr=subset_cxr,
            )
            if prefix == '':
                fused_loss = loss
        return fused_loss

    def _run_val_pass(self, batch, *, prefix, cxr_override, ehr_override, subset_cxr):
        """Run one validation forward pass under a (possibly overridden)
        modality-presence configuration and accumulate predictions into
        per-mode buckets keyed by ``prefix``.

        prefix=''           → fused (raw masks from the batch); logs val_loss /
                              val_cls_loss / val_reg_loss as before.
        prefix='ehr_only_'  → cxr_present forced to False on every sample.
        prefix='img_only_'  → ehr_present forced to False; only run on the
                              subset of samples with original cxr_present=True
                              (otherwise both modalities are off → garbage).
        """
        data = batch['data']
        label = batch['label']

        (cat_feats, float_feats, cat_valid_mask, float_valid_mask,
         cxr_images, cxr_present, cohort_id, ehr_present, cxr_slots) = self._extract_multimodal(data)

        # Build the sample subset for this mode. img_only mode is only
        # well-defined for patients who actually carry a CXR.
        keep_idx = None
        if subset_cxr:
            if cxr_present is None or not cxr_present.any():
                return None  # nothing to evaluate for image-only on this batch
            if cxr_present.dim() == 2:
                keep_idx = cxr_present.any(dim=-1).nonzero(as_tuple=True)[0]
            else:
                keep_idx = cxr_present.nonzero(as_tuple=True)[0]

        def _slice(t):
            if t is None or keep_idx is None:
                return t
            return t[keep_idx]

        def _slice_slots(slots, images):
            """Packed CXR tensors use batch indices in slots — remap after subset."""
            if keep_idx is None:
                return slots, images
            if slots is None or images is None or slots.numel() == 0:
                return slots, images
            old_to_new = {int(old): new for new, old in enumerate(keep_idx.tolist())}
            keep_rows = [i for i, b in enumerate(slots[:, 0].tolist()) if int(b) in old_to_new]
            if not keep_rows:
                side = images.shape[-1] if images.ndim >= 3 else 518
                empty_img = images.new_zeros(0, 3, side, side) if images.ndim == 4 else images[:0]
                return slots.new_zeros(0, 2), empty_img
            idx = torch.tensor(keep_rows, device=slots.device, dtype=torch.long)
            slots = slots[idx].clone()
            images = images[idx]
            slots[:, 0] = torch.tensor(
                [old_to_new[int(b)] for b in slots[:, 0].tolist()],
                device=slots.device, dtype=slots.dtype,
            )
            return slots, images

        cat_feats = _slice(cat_feats)
        float_feats = _slice(float_feats)
        cat_valid_mask = _slice(cat_valid_mask)
        float_valid_mask = _slice(float_valid_mask)
        cxr_present = _slice(cxr_present)
        ehr_present = _slice(ehr_present)
        cohort_id = _slice(cohort_id)
        cls_label = _slice(label['cat_feats'])
        cls_mask = _slice(label['cat_valid_mask'])
        reg_label = _slice(label['float_feats'])
        reg_mask = _slice(label['float_valid_mask'])
        time_index = _slice(data.get('time_index'))
        cxr_slots, cxr_images = _slice_slots(cxr_slots, cxr_images)

        # Apply mode overrides AFTER subsetting.
        if cxr_override == 'off' and cxr_present is not None:
            cxr_present = torch.zeros_like(cxr_present)
        if ehr_override == 'off' and ehr_present is not None:
            ehr_present = torch.zeros_like(ehr_present)

        valid_mask = cat_valid_mask.any(dim=1) | float_valid_mask.any(dim=1)
        if time_index is None:
            time_index = torch.arange(
                cat_feats.shape[-1], device=cat_feats.device,
            ).unsqueeze(0).expand(cat_feats.shape[0], -1)
        else:
            time_index = time_index.to(device=cat_feats.device).clamp(min=0)

        pretrain_outputs, aux = self.model(
            cat_feats, float_feats, valid_mask, time_index,
            cxr_images=cxr_images, cxr_present=cxr_present, ehr_present=ehr_present,
            cxr_slots=cxr_slots,
        )

        cls_loss, reg_loss, next_loss = self._compute_pretrain_loss(
            pretrain_outputs, cls_label, cls_mask, reg_label, reg_mask,
        )
        # Only log losses/aux for the default fused pass; the per-mode metrics
        # are aggregated in on_validation_epoch_end below.
        if prefix == '':
            vae_loss = self._compute_vae_loss(aux['vae'], prefix='val')
            adv_loss = self._compute_adv_losses(
                aux, cat_feats, float_feats, cohort_id, valid_mask, prefix='val',
            )
            loss, _, _ = self._combine_pretrain_losses(
                cls_loss, reg_loss, vae_loss, adv_loss,
            )
            self.log("val_loss", loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
            self.log("val_cls_loss", cls_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
            self.log("val_reg_loss", reg_loss, prog_bar=False, rank_zero_only=True, on_epoch=True)
        else:
            loss = cls_loss + reg_loss + next_loss

        cls_preds = pretrain_outputs['cls_current']
        reg_preds = pretrain_outputs['reg_current']

        tensor_to_gather = [
            cls_label.contiguous(), cls_mask.contiguous(),
            reg_label.contiguous(), reg_mask.contiguous(),
        ] + [p.contiguous() for p in cls_preds] + [p.contiguous() for p in reg_preds]

        if dist.is_initialized():
            tensor_gathered = [x.cpu() for x in all_gather(tensor_to_gather)]
        else:
            tensor_gathered = [x.cpu() for x in tensor_to_gather]

        cls_label = tensor_gathered[0]
        cls_mask = tensor_gathered[1]
        reg_label = tensor_gathered[2]
        reg_mask = tensor_gathered[3]

        gathered_cls_preds = tensor_gathered[4:4 + len(cls_preds)]
        gathered_reg_preds = tensor_gathered[4 + len(cls_preds):]

        for i in range(len(self.cls_label_names)):
            if i >= len(gathered_cls_preds) or i >= cls_label.shape[1]:
                continue
            mask = cls_mask[:, i, :].reshape(-1).bool()
            pp = gathered_cls_preds[i].reshape(-1, 2)
            yy = cls_label[:, i, :].reshape(-1)
            if mask.sum() > 2:
                self.preds[f'{prefix}cls_{i}'].append(pp[mask, 1])
                self.targets[f'{prefix}cls_{i}'].append(yy[mask])

        for i in range(len(self.reg_label_names)):
            if i >= len(gathered_reg_preds) or i >= reg_label.shape[1]:
                continue
            mask = reg_mask[:, i, :].reshape(-1).bool()
            pp = gathered_reg_preds[i].reshape(-1)
            yy = reg_label[:, i, :].reshape(-1)
            if mask.sum() > 2:
                self.preds[f'{prefix}reg_{i}'].append(pp[mask])
                self.targets[f'{prefix}reg_{i}'].append(yy[mask])

        return loss

    def on_validation_epoch_end(self) -> None:
        # Iterate every mode we accumulated this epoch. Modes present are
        # implied by the bucket keys; default (no prefix) is always there.
        prefixes = sorted({k.rsplit('cls_', 1)[0].rsplit('reg_', 1)[0]
                            for k in self.preds.keys()})

        for prefix in prefixes:
            mauc, mf1 = [], []
            for i, k in enumerate(self.cls_label_names):
                key = f'{prefix}cls_{i}'
                if not self.preds[key]:
                    if prefix == '':
                        self.log(f"val_{k}_auc", torch.nan,
                                 prog_bar=False, rank_zero_only=True)
                    continue
                pred = dim_zero_cat(self.preds[key]).double()
                target = dim_zero_cat(self.targets[key])
                precision, recall, _ = precision_recall_curve(target.numpy(), pred.numpy())
                precision += 1e-10
                recall += 1e-10
                f1 = 2 * recall * precision / (recall + precision)
                best_f1 = float(np.max(f1))
                mf1.append(best_f1)
                auc_score = MF.auroc(pred, target, task='binary')
                self.log(f"val_{prefix}{k}_auc", auc_score,
                         prog_bar=False, rank_zero_only=True)
                self.log(f"val_{prefix}{k}_f1", best_f1,
                         prog_bar=False, rank_zero_only=True)
                mauc.append(auc_score.item())
            if mauc:
                self.log(f"val_{prefix}mauc", sum(mauc) / len(mauc),
                         prog_bar=(prefix == ''), rank_zero_only=True)
            if mf1:
                self.log(f"val_{prefix}mf1", sum(mf1) / len(mf1),
                         prog_bar=(prefix == ''), rank_zero_only=True)

            mpcc, mr2 = [], []
            for i, k in enumerate(self.reg_label_names):
                key = f'{prefix}reg_{i}'
                if not self.preds[key]:
                    continue
                pred = dim_zero_cat(self.preds[key]).double()
                target = dim_zero_cat(self.targets[key]).double()
                self.log(f"val_{prefix}{k}_mse",
                         MF.mean_squared_error(pred, target),
                         prog_bar=False, rank_zero_only=True)
                pcc = MF.pearson_corrcoef(pred, target)
                r2 = MF.r2_score(pred, target)
                self.log(f"val_{prefix}{k}_pcc", pcc,
                         prog_bar=False, rank_zero_only=True)
                self.log(f"val_{prefix}{k}_r2", r2,
                         prog_bar=False, rank_zero_only=True)
                mpcc.append(pcc.item())
                mr2.append(r2.item())
            if mpcc:
                self.log(f"val_{prefix}mpcc", sum(mpcc) / len(mpcc),
                         prog_bar=(prefix == ''), rank_zero_only=True)
            if mr2:
                self.log(f"val_{prefix}mr2", sum(mr2) / len(mr2),
                         prog_bar=(prefix == ''), rank_zero_only=True)

    # ------------------------------------------------------------------
    # Testing
    # ------------------------------------------------------------------

    def on_test_epoch_start(self) -> None:
        self.test_outputs = []

    def test_step(self, batch, batch_idx):
        data = batch['data']
        pid = batch['pid']
        label = batch['label']

        (cat_feats, float_feats, cat_valid_mask, float_valid_mask,
         cxr_images, cxr_present, _, ehr_present, cxr_slots) = self._extract_multimodal(data)

        reg_label = label['float_feats']
        cls_label = label['cat_feats']
        reg_mask = label['float_valid_mask']

        valid_mask = cat_valid_mask.any(dim=1) | float_valid_mask.any(dim=1)
        time_index = self._batch_time_index(data, cat_feats)

        pretrain_outputs, _aux = self.model(
            cat_feats, float_feats, valid_mask, time_index,
            cxr_images=cxr_images, cxr_present=cxr_present, ehr_present=ehr_present,
            cxr_slots=cxr_slots,
        )

        cls_preds = pretrain_outputs['cls_current']
        reg_preds = pretrain_outputs['reg_current']

        if cls_preds:
            y_cls = torch.stack(
                [torch.softmax(p, dim=-1) for p in cls_preds], dim=1,
            )
        else:
            y_cls = torch.empty(cat_feats.shape[0], 0, cat_feats.shape[2], 2)

        if reg_preds:
            y_reg = torch.stack(reg_preds, dim=1)
        else:
            y_reg = torch.empty(cat_feats.shape[0], 0, cat_feats.shape[2])

        self.test_outputs.append({
            'pid': pid,
            'cls_preds': y_cls.float().cpu().numpy(),
            'cls_label': cls_label.cpu().numpy(),
            'reg_preds': y_reg.float().cpu().numpy(),
            'reg_label': reg_label.cpu().numpy(),
            'reg_mask': reg_mask.cpu().numpy(),
        })

        if batch_idx % 50 == 0:
            torch.cuda.empty_cache()

    def on_test_epoch_end(self):
        output_dir = Path(self.output_dir) / self.pred_folder
        output_dir.mkdir(parents=True, exist_ok=True)

        n_cls = len(self.cls_label_names)
        n_reg = len(self.reg_label_names)

        all_pids = []
        cls_probs = [[] for _ in range(n_cls)]
        cls_labels = [[] for _ in range(n_cls)]
        reg_preds_all = [[] for _ in range(n_reg)]
        reg_masks_all = [[] for _ in range(n_reg)]
        reg_labels_all = [[] for _ in range(n_reg)]

        for output in tqdm(self.test_outputs):
            all_pids.extend(output['pid'] if isinstance(output['pid'], list)
                            else [output['pid']])

            for b_idx in range(output['cls_preds'].shape[0]):
                for i in range(n_cls):
                    if i < output['cls_preds'].shape[1]:
                        cls_probs[i].append(output['cls_preds'][b_idx, i, :, 1].mean())
                        cls_labels[i].append(output['cls_label'][b_idx, i, :].mean())

                for i in range(n_reg):
                    if i < output['reg_preds'].shape[1]:
                        reg_preds_all[i].append(output['reg_preds'][b_idx, i, :].mean())
                        reg_masks_all[i].append(output['reg_mask'][b_idx, i, :].any())
                        reg_labels_all[i].append(output['reg_label'][b_idx, i, :].mean())

        data_dict = {'pid': all_pids}
        for i, col in enumerate(self.cls_label_names):
            if i < len(cls_probs):
                data_dict[f"{col}_prob_1"] = cls_probs[i]
                data_dict[col] = cls_labels[i]
        for i, col in enumerate(self.reg_label_names):
            if i < len(reg_preds_all):
                data_dict[f"{col}_prob_0"] = reg_preds_all[i]
                data_dict[f"{col}_mask"] = reg_masks_all[i]
                data_dict[col] = reg_labels_all[i]

        df = pd.DataFrame(data_dict)
        output_path = output_dir / f'test_pred.{self.global_rank}.parquet'
        df.to_parquet(output_path)
        self.test_outputs.clear()
        gc.collect()
        torch.cuda.empty_cache()
