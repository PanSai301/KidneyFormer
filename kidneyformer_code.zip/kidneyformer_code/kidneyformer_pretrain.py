"""Kidneyformer pretraining script with feature-level masking."""
import argparse
import sys
import warnings
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import torch
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import (
    LearningRateMonitor, ModelCheckpoint, TQDMProgressBar,
)
from pytorch_lightning.loggers import CSVLogger, WandbLogger
from transformers import GPT2Config

from kidneyformer_code.kidneyformer_dataset import OncoDataModule
from kidneyformer_code.kidneyformer_pretrain_module import OncoModule
from Utils import json_load, get_max_version, load_ckpt

# Validation metrics are computed on CPU after a manual all_gather and logged
# with rank_zero_only=True; the framework's "sync_dist=True" suggestion does
# not apply (sync_dist on CPU triggers a CPU-NCCL reduction that fails).
warnings.filterwarnings(
    'ignore',
    message=r"It is recommended to use `self\.log\(.*sync_dist=True.*",
)
# DDP bucket stride mismatch on DINOv2's cls_token / pos_embed (shape [1,1,D])
# when the CXR backbone is unfrozen. The mismatch is purely on a size-1 dim so
# it does not change memory access — the cost is one ~4 KB memcpy per backward,
# negligible against multi-GB/s gradient sync.
warnings.filterwarnings(
    'ignore',
    message=r"Grad strides do not match bucket view strides.*",
)


def main(config):
    debug = config['debug']
    output_dir = Path(config['output_dir'])
    n_gpus = config['n_gpus']
    n_epoch = config['n_epoch']

    data_module = OncoDataModule(config)
    data_module.setup()

    model_module = OncoModule(config)

    # Optional weight-only resume from a prior pretrain run (or any
    # state-compatible checkpoint). We deliberately DON'T resume the
    # optimizer/scheduler state — pretrained_ckpt_path is for cases where
    # the user changed `n_epoch` or LR, so the schedule needs to be fresh.
    # For full optimizer+scheduler resume use Lightning's `trainer.fit(
    # ckpt_path=...)` instead.
    ckpt_path = config.get('pretrained_ckpt_path', '')
    if ckpt_path and Path(ckpt_path).exists():
        print(f"[pretrain] loading weights from {ckpt_path}")
        ckpt = load_ckpt(ckpt_path, map_location='cpu')
        missing, unexpected = model_module.load_state_dict(
            ckpt['state_dict'], strict=False,
        )
        if missing:
            print(f"[pretrain]   missing keys: {len(missing)} (first 5: {missing[:5]})")
        if unexpected:
            print(f"[pretrain]   unexpected keys: {len(unexpected)} (first 5: {unexpected[:5]})")

    log_dir = output_dir / 'log'
    if not config['train'] and config['test']:
        version = get_max_version(str(log_dir))
    else:
        version = None
    logger_csv = CSVLogger(str(log_dir), version=version)
    version_dir = Path(logger_csv.log_dir)
    loggers = [logger_csv]
    if not debug:
        logger_wandb = WandbLogger(project=config['project'], name=config['name'])
        loggers.append(logger_wandb)

    # Checkpoint policy for pretrain:
    # 1) Unconditional every-epoch last.ckpt (monitor=None). Do NOT monitor
    #    train_loss_epoch with mode=min+save_top_k=1 — if loss stops improving,
    #    some Lightning versions skip the save path and last.ckpt stalls.
    # 2) Best val_loss / val_mpcc on validation epochs only.
    ckpt_every = int(config.get('snapshot_every_n_epochs', 10))
    ckpt_dir = version_dir / 'checkpoint'
    callbacks = [
        ModelCheckpoint(
            dirpath=ckpt_dir,
            filename='epoch{epoch:03d}',
            monitor=None,
            save_top_k=1,
            save_last=True,
            every_n_epochs=1,
            save_on_train_epoch_end=True,
        ),
        ModelCheckpoint(
            dirpath=ckpt_dir,
            filename='{epoch}-{val_loss:.4f}',
            monitor='val_loss', mode='min',
            save_top_k=1, save_last=False,
            save_on_train_epoch_end=False,
        ),
        ModelCheckpoint(
            dirpath=ckpt_dir,
            filename='best-val_loss-{epoch}-{val_loss:.4f}',
            monitor='val_loss', mode='min',
            every_n_epochs=ckpt_every, save_top_k=1, save_last=False,
            save_on_train_epoch_end=False,
        ),
        ModelCheckpoint(
            dirpath=ckpt_dir,
            filename='best-val_mpcc-{epoch}-{val_mpcc:.4f}',
            monitor='val_mpcc', mode='max',
            every_n_epochs=ckpt_every, save_top_k=1, save_last=False,
            save_on_train_epoch_end=False,
        ),
        TQDMProgressBar(refresh_rate=config.get('tqdm_refresh', 50)),
    ]
    callbacks.append(LearningRateMonitor(logging_interval='epoch'))

    if config['train']:
        # `ddp_find_unused_parameters_true` runs a graph trace every step to
        # locate unused params; expensive and unnecessary here (every parameter
        # is touched on every step). Plain `ddp` is the right setting.
        trainer = Trainer(
            accelerator='gpu', devices=n_gpus,
            max_epochs=n_epoch,
            logger=loggers,
            callbacks=callbacks,
            strategy='ddp_find_unused_parameters_true',
            precision=config.get('precision', 'bf16-mixed'),
            sync_batchnorm=False,  # no BN in the model; skip the sync.
            log_every_n_steps=config.get('log_every_n_steps', 50),
            check_val_every_n_epoch=config.get('val_every_n_epoch', 1),
            accumulate_grad_batches=int(config.get('accumulate_grad_batches', 1)),
            gradient_clip_val=float(config.get('grad_clip_norm', 1.0)),
            benchmark=True,
        )
        # Full resume: restores optimizer state, LR scheduler position, epoch
        # counter and RNG. The config MUST match the saved run (same arch,
        # same freeze_cxr_backbone, same use_vae, …) or the optimizer state
        # won't deserialize. For cross-config init use pretrained_ckpt_path
        # above instead.
        resume_ckpt = config.get('resume_ckpt_path', '')
        fit_kwargs = {}
        if resume_ckpt and Path(resume_ckpt).exists():
            print(f"[pretrain] resuming full Lightning state from {resume_ckpt}")
            fit_kwargs['ckpt_path'] = resume_ckpt
        trainer.fit(model_module, datamodule=data_module, **fit_kwargs)

    if config['test']:
        trainer = Trainer(
            inference_mode=True,
            accelerator='gpu', devices=[n_gpus[0]],
        )
        ckpt = load_ckpt(config['ckpt_path'], map_location='cpu')
        model_module.load_state_dict(ckpt['state_dict'], strict=False)
        trainer.test(model_module, datamodule=data_module)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Kidneyformer pretraining')
    parser.add_argument(
        '--config', type=str,
        default='configs/pretrain_sample.json',
        help='Path to the pretraining configuration JSON file',
    )
    args = parser.parse_args()

    config = json_load(args.config)

    # Build transformer config from JSON specification
    transformer_cfg = config.get('transformer', {})
    gpt2_config = GPT2Config(
        vocab_size=transformer_cfg.get('vocab_size', 32000),
        n_embd=transformer_cfg.get('hidden_size', 768),
        n_layer=transformer_cfg.get('num_hidden_layers', 12),
        n_head=transformer_cfg.get('num_attention_heads', 12),
        n_inner=transformer_cfg.get('intermediate_size', 3072),
        activation_function=transformer_cfg.get('hidden_act', 'gelu'),
        resid_pdrop=transformer_cfg.get('hidden_dropout_prob', 0.1),
        attn_pdrop=transformer_cfg.get('attention_probs_dropout_prob', 0.1),
        n_positions=transformer_cfg.get('max_position_embeddings', 64),
        layer_norm_epsilon=transformer_cfg.get('layer_norm_eps', 1e-12),
    )
    gpt2_config.n_positions = config.get('seq_max_len', 64)
    config['transformer'] = gpt2_config

    config['mode'] = 'pretrain'
    config['feat_info'] = json_load(config['feat_info_path'])

    main(config)
