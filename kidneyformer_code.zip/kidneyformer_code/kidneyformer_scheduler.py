"""Minimal CosineAnnealingWarmupRestarts (vendor; PyPI may be unavailable)."""
from __future__ import annotations

import math

from torch.optim.lr_scheduler import _LRScheduler


class CosineAnnealingWarmupRestarts(_LRScheduler):
    """Cosine annealing with linear warmup (single cycle covering n_epoch steps)."""

    def __init__(
        self,
        optimizer,
        first_cycle_steps: int,
        cycle_mult: float = 1.0,
        max_lr: float = 0.1,
        min_lr: float = 1e-8,
        warmup_steps: int = 0,
        gamma: float = 1.0,
        last_epoch: int = -1,
    ):
        assert first_cycle_steps > 0
        assert warmup_steps < first_cycle_steps
        self.first_cycle_steps = int(first_cycle_steps)
        self.cycle_mult = float(cycle_mult)
        self.base_max_lr = float(max_lr)
        self.max_lr = float(max_lr)
        self.min_lr = float(min_lr)
        self.warmup_steps = int(warmup_steps)
        self.gamma = float(gamma)
        self.cycle = 0
        self.step_in_cycle = last_epoch
        self.cycle_steps = self.first_cycle_steps
        super().__init__(optimizer, last_epoch)
        self._init_lr()

    def _init_lr(self):
        self.base_lrs = []
        # Per-group peak LRs (layered backbone/head schedules).
        self.max_lrs = []
        for param_group in self.optimizer.param_groups:
            peak = float(param_group.get("initial_lr", param_group.get("lr", self.max_lr)))
            self.max_lrs.append(peak)
            param_group["lr"] = self.min_lr
            self.base_lrs.append(self.min_lr)

    def get_lr(self):
        max_lrs = getattr(self, "max_lrs", None) or [self.max_lr] * len(self.base_lrs)
        if self.step_in_cycle == -1:
            return self.base_lrs
        if self.step_in_cycle < self.warmup_steps:
            return [
                self.min_lr + (mx - self.min_lr) * self.step_in_cycle / max(1, self.warmup_steps)
                for mx in max_lrs
            ]
        progress = (self.step_in_cycle - self.warmup_steps) / max(
            1, (self.cycle_steps - self.warmup_steps)
        )
        return [
            self.min_lr + (mx - self.min_lr) * (1 + math.cos(math.pi * progress)) / 2
            for mx in max_lrs
        ]

    def step(self, epoch=None):
        if epoch is None:
            epoch = self.last_epoch + 1
            self.step_in_cycle = self.step_in_cycle + 1
            if self.step_in_cycle >= self.cycle_steps:
                self.cycle += 1
                self.step_in_cycle = self.step_in_cycle - self.cycle_steps
                self.cycle_steps = (
                    int((self.cycle_steps - self.warmup_steps) * self.cycle_mult) + self.warmup_steps
                )
                self.max_lr = self.base_max_lr * (self.gamma ** self.cycle)
        else:
            if epoch >= self.first_cycle_steps:
                if self.cycle_mult == 1.0:
                    self.step_in_cycle = epoch % self.first_cycle_steps
                    self.cycle = epoch // self.first_cycle_steps
                else:
                    n = int(
                        math.log(
                            (epoch / self.first_cycle_steps * (self.cycle_mult - 1) + 1),
                            self.cycle_mult,
                        )
                    )
                    self.cycle = n
                    self.step_in_cycle = epoch - int(
                        self.first_cycle_steps * (self.cycle_mult ** n - 1) / (self.cycle_mult - 1)
                    )
                    self.cycle_steps = self.first_cycle_steps * (self.cycle_mult ** n)
                self.max_lr = self.base_max_lr * (self.gamma ** self.cycle)
            else:
                self.step_in_cycle = epoch
        self.last_epoch = math.floor(epoch)
        for param_group, lr in zip(self.optimizer.param_groups, self.get_lr()):
            param_group["lr"] = lr
