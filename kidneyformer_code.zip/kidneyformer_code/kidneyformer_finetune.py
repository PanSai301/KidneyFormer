"""Kidneyformer finetuning script for downstream clinical prediction tasks."""
import argparse
import sys
import warnings
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import torch
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import (
    EarlyStopping, LearningRateMonitor, ModelCheckpoint, TQDMProgressBar,
)
from pytorch_lightning.loggers import CSVLogger, WandbLogger
from transformers import GPT2Config

from kidneyformer_code.kidneyformer_dataset import OncoDataModule
from kidneyformer_code.kidneyformer_finetune_module import OncoModule
from Utils import json_load, get_max_version, load_ckpt

# See pretrain.py for rationale.
warnings.filterwarnings(
    'ignore',
    message=r"It is recommended to use `self\.log\(.*sync_dist=True.*",
)
warnings.filterwarnings(
    'ignore',
    message=r"Grad strides do not match bucket view strides.*",
)

torch._dynamo.config.optimize_ddp = False


def load_pretrained_expanding_types(model_module, ckpt_path: str) -> None:
    """Load a checkpoint, expanding tables that grew after pretraining.

    Handles:
      * token-type embeddings when float/category channels were appended;
      * temporal embeddings when switching to signed (treatment-relative) time
        (copy the old [0..T] rows into the positive half of [-T..T]).
    """
    ckpt = load_ckpt(ckpt_path, map_location='cpu')
    state = ckpt['state_dict']
    current = model_module.state_dict()
    patched = {}
    for key, src in state.items():
        dst = current.get(key)
        if (
            dst is not None
            and key.endswith('token_type_embeddings.weight')
            and tuple(src.shape) != tuple(dst.shape)
            and src.shape[1] == dst.shape[1]
            and src.shape[0] < dst.shape[0]
        ):
            expanded = dst.detach().cpu().clone()
            expanded[: src.shape[0]] = src
            patched[key] = expanded
            print(
                f'expanded {key} {tuple(src.shape)} -> {tuple(expanded.shape)}',
                flush=True,
            )
        elif (
            dst is not None
            and 'temporal_embedding.temporal_embedding.weight' in key
            and tuple(src.shape) != tuple(dst.shape)
            and src.shape[1] == dst.shape[1]
            and src.shape[0] < dst.shape[0]
        ):
            # Signed-time table is 2T+1; map old day-k → index (T+k).
            expanded = dst.detach().cpu().clone()
            t_old = src.shape[0] - 1
            offset = (dst.shape[0] - 1) // 2
            n_copy = min(t_old, offset) + 1
            expanded[offset: offset + n_copy] = src[:n_copy]
            patched[key] = expanded
            print(
                f'expanded signed-time {key} {tuple(src.shape)} -> {tuple(expanded.shape)} '
                f'(offset={offset})',
                flush=True,
            )
        else:
            patched[key] = src
    missing, unexpected = model_module.load_state_dict(patched, strict=False)
    print(f'pretrained load missing={len(missing)} unexpected={len(unexpected)}', flush=True)


def main(config):
    debug = config['debug']
    output_dir = Path(config['output_dir'])
    n_gpus = config['n_gpus']
    n_epoch = config['n_epoch']

    data_module = OncoDataModule(config)
    data_module.setup()

    model_module = OncoModule(config)

    ckpt_path = config.get('pretrained_ckpt_path', '')
    if ckpt_path and Path(ckpt_path).exists():
        load_pretrained_expanding_types(model_module, ckpt_path)

    log_dir = output_dir / 'log'
    if not config['train'] and config['test']:
        version = get_max_version(str(log_dir))
    else:
        version = None
    logger_csv = CSVLogger(str(log_dir), version=version)
    version_dir = Path(logger_csv.log_dir)
    loggers = [logger_csv]
    if not debug:
        logger_wandb = WandbLogger(project=config['project'])
        loggers.append(logger_wandb)

    callbacks = [
        ModelCheckpoint(
            dirpath=(version_dir / 'checkpoint'),
            filename='{epoch}-{' + config.get('ckpt_monitor', 'val_mauc') + ':.3f}',
            monitor=config.get('ckpt_monitor', 'val_mauc'),
            mode=config.get('ckpt_monitor_mode', 'max'),
            save_last=True, save_top_k=1,
        ),
        TQDMProgressBar(refresh_rate=config.get('tqdm_refresh', 50)),
    ]
    callbacks.append(LearningRateMonitor(logging_interval='epoch'))
    if config.get('early_stopping', True):
        callbacks.append(EarlyStopping(
            monitor=config.get('early_stop_monitor', config.get('ckpt_monitor', 'val_mauc')),
            mode=config.get('early_stop_mode', config.get('ckpt_monitor_mode', 'max')),
            patience=int(config.get('early_stop_patience', 15)),
            min_delta=float(config.get('early_stop_min_delta', 0.0)),
            verbose=True,
        ))

    if config['train']:
        trainer = Trainer(
            accelerator='gpu', devices=n_gpus,
            max_epochs=n_epoch,
            logger=loggers,
            callbacks=callbacks,
            strategy='ddp_find_unused_parameters_true',
            precision=config.get('precision', 'bf16-mixed'),
            sync_batchnorm=False,
            log_every_n_steps=config.get('log_every_n_steps', 50),
            check_val_every_n_epoch=config.get('val_every_n_epoch', 1),
            accumulate_grad_batches=int(config.get('accumulate_grad_batches', 1)),
            benchmark=True,
        )
        trainer.fit(
            model_module,
            datamodule=data_module,
            ckpt_path=config.get('resume_ckpt_path') or None,
        )
        # Prefer best val_mauc ckpt for subsequent test; fall back to last.
        best = getattr(trainer.checkpoint_callback, 'best_model_path', '') or ''
        last = getattr(trainer.checkpoint_callback, 'last_model_path', '') or ''
        if best:
            config['ckpt_path'] = best
        elif last and not config.get('ckpt_path'):
            config['ckpt_path'] = last

    if config['test']:
        ckpt_path = config.get('ckpt_path') or config.get('pretrained_ckpt_path', '')
        if not ckpt_path:
            raise ValueError('test=true requires ckpt_path or pretrained_ckpt_path')
        # Persist resolved ckpt for chained val-pred / Youden scripts.
        config['_resolved_ckpt_path'] = ckpt_path
        resolved_path = version_dir / 'resolved_ckpt.txt'
        resolved_path.parent.mkdir(parents=True, exist_ok=True)
        resolved_path.write_text(str(ckpt_path) + '\n')
        print(f"[finetune] test ckpt -> {ckpt_path}")
        trainer = Trainer(
            inference_mode=True,
            accelerator='gpu', devices=n_gpus,
            strategy='ddp_find_unused_parameters_true',
            precision=config.get('precision', 'bf16-mixed'),
        )
        ckpt = load_ckpt(ckpt_path, map_location='cpu')
        model_module.load_state_dict(ckpt['state_dict'], strict=False)
        trainer.test(model_module, datamodule=data_module)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Kidneyformer finetuning')
    parser.add_argument(
        '--config', type=str,
        default='configs/finetune_sample.json',
        help='Path to the finetuning configuration JSON file',
    )
    args = parser.parse_args()

    config = json_load(args.config)

    # Build transformer config; override key architectural parameters
    transformer_cfg = config.get('transformer', {})
    gpt2_config = GPT2Config(
        vocab_size=transformer_cfg.get('vocab_size', 32000),
        n_embd=transformer_cfg.get('hidden_size', 768),
        n_layer=transformer_cfg.get('num_hidden_layers', 12),
        n_head=transformer_cfg.get('num_attention_heads', 12),
        n_inner=transformer_cfg.get('intermediate_size', 3072),
        activation_function=transformer_cfg.get('hidden_act', 'gelu'),
        resid_pdrop=transformer_cfg.get('hidden_dropout_prob', 0.1),
        attn_pdrop=transformer_cfg.get('attention_probs_dropout_prob', 0.1),
        n_positions=transformer_cfg.get('max_position_embeddings', 64),
        layer_norm_epsilon=transformer_cfg.get('layer_norm_eps', 1e-12),
    )
    gpt2_config.n_positions = config.get('seq_max_len', 64)
    config['transformer'] = gpt2_config

    if 'feat_info_path' in config:
        config['feat_info'] = json_load(config['feat_info_path'])

    main(config)
